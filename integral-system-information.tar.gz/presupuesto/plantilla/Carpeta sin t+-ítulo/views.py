from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from presupuesto.forms import *
from presupuesto.models import *
from rrhh.models import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q
from unidad.views import comprobar_perfil, registrar_log

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from unidad.forms import Formulario_Departamento, Formulario_Unidad,  Formulario_Plaza_Departamento
from rrhh.forms import  Formulario_Trabajador
from django.db.models import Sum
from django.db.models import Count

# Create your views here.


@login_required(login_url='/ingresar')
def presupuesto(request):
	id_unidad=request.session['unidad']
	if request.GET.get('id'):
		id_unidad = request.GET.get('id')

	unidadb= Unidad.objects.get(id=id_unidad)

	gastos = Orden_Servicio_Unidad.objects.filter(unidad=unidadb).order_by('-actualizacion')
	presup = Presupuesto_Unidad.objects.get(unidad=unidadb)

	p_ini = presup.cantidad_inicial
	p_actual = presup.cantidad_actual
	porciento = porciento_Ejecucion(id_unidad)


	unidades= Unidad.objects.filter(subordinacion=unidadb).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	preXudad = [[]]

	for unidad1 in unidades:
		if len(Presupuesto_Unidad.objects.filter(unidad=unidad1)) > 0:
			presup = Presupuesto_Unidad.objects.get(unidad=unidad1)
			porciento2 = porciento_Ejecucion(unidad1.id)
			fila = [unidad1, presup, porciento2]
			preXudad.append(fila)

	preXudad.pop(0)

	return render_to_response('presupuesto.html',{'p_ini':p_ini,'p_actual':p_actual, 'porciento':porciento, 'unidad':unidadb, 'gastos':gastos, 'preXudad':preXudad}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def modificar_presupuesto(request):
	id_unidad = request.GET.get('id')

	unidadb=Unidad.objects.get(id=id_unidad)
	permiso = comprobar_perfil(request,id_unidad)

	presup = Presupuesto_Unidad.objects.get(unidad=unidadb)
	presup_actual = presup.cantidad_actual

	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_orden = Formulario_Orden_Servicio_Unidad(request.POST)
		if form_orden.is_valid():

			form = form_orden.save(commit=False)
			if form.importe <= presup_actual:
				form.unidad = unidadb
				form.save()
				presup.cantidad_actual = presup_actual - int(form.importe)
				presup.save()
				acciones='El presupuesto de la unidad'+ str(unidadb.nombre) + " de "+ unidadb.municipio.municipio + " fue modificado correctamente."
				registrar_log(request,acciones,4)
				return HttpResponseRedirect('/presupuesto')
			else:
				form_orden = Formulario_Orden_Servicio_Unidad(instance=form)
				msg = "**Revise el importe de su Orden de Servicio. Es mayor que su saldo actual."
				return render_to_response('formulario.presupuesto.html',{'unidad':unidadb, 'form_orden':form_orden, 'msg':msg} , context_instance=RequestContext(request))
	else:

		form_orden = Formulario_Orden_Servicio_Unidad()
	return render_to_response('formulario.presupuesto.html',{'unidad':unidadb, 'form_orden':form_orden} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def presupuesto_unidades_sub(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)

	unidades= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	preXudad = [[]]

	for unidad1 in unidades:
		if len(Presupuesto_Unidad.objects.filter(unidad=unidad1)) > 0:
			presup = Presupuesto_Unidad.objects.get(unidad=unidad1)
			porciento = porciento_Ejecucion(unidad1.id)
			fila = [unidad1, presup.cantidad_inicial, presup.cantidad_actual, porciento]
			preXudad.append(fila)
			for perfil1 in perfiles:
				if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
					perfil[unidad1.id]=unidad1.id

	preXudad.pop(0)
	return render_to_response('presupuesto_unidades_sub.html',{'preXudad':preXudad,'unidad':unidad, 'perfil':perfil}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def info_servicio(request):
	id_servicio = request.GET.get('id')

	servicio = Orden_Servicio_Unidad.objects.get(id=id_servicio)
	return render_to_response('info_servicio.html',{'servicio':servicio,'unidad':servicio.unidadl}, context_instance=RequestContext(request))

def porciento_Ejecucion(id_unidad):
	unidadb= Unidad.objects.get(id=id_unidad)
	presup = Presupuesto_Unidad.objects.get(unidad=unidadb)

	p_ini = presup.cantidad_inicial
	p_actual = presup.cantidad_actual
	porciento = (p_ini - p_actual) * 100 / p_ini

	return porciento
