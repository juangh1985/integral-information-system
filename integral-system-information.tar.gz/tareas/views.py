#!/usr/bin/python
# -*- coding: utf-8 -*-
import os, sys
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from tareas.views import *
from rrhh.models import *
from tareas.models import *
from tareas.forms import *
from unidad.views import *
from inspeccion.views import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q
from models import *

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required

from django.db.models import Sum
from django.db.models import Count


import time
from datetime import datetime, date, time, timedelta





import calendar
from io import BytesIO

from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Table, TableStyle,CondPageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, inch, landscape, portrait
from reportlab.lib.enums import TA_CENTER
from django.views.generic import UpdateView, ListView



def actividad(request):
	t = date.today()
	y = t.year
	a = datetime(y, 1, 1, 0, 0, 0)
	b = datetime(y, 12, 31, 0, 0, 0)

	tar = Tarea.objects.filter(responsable=1, clasificacion=1, fini__gte = a, ffin__lte = b)
	#tar = Tarea.objects.filter(responsable=1, clasificacion=1)
	return render_to_response('tareas/actividades.html',{'tar':tar} , context_instance=RequestContext(request))





def anual(request):
	t = date.today()
	y = t.year
	a = datetime(y, 1, 1, 0, 0, 0)
	b = datetime(y, 12, 31, 0, 0, 0)

	#tar = Tarea.objects.filter(responsable=1, clasificacion=1)
	tar = Tarea.objects.filter(responsable=1, clasificacion=1, fini__gte = a, ffin__lte = b).order_by('fini')
	return render_to_response('tareas/anual.html',{'tar':tar} , context_instance=RequestContext(request))
















@login_required(login_url='/ingresar')
def tareas(request):

	tres = timedelta(4*365/12)
	mastres = date.today() + timedelta(4*365/12)
	menostres = date.today() - timedelta(4*365/12)



	ano=[]
	anobase=2015
	ano.append(anobase)
	anoactual=int(datetime.now().strftime('%Y'))
	rango=anoactual-anobase
	if rango > 0:
		for i in range(rango):
			ano.append(anobase+i+1)


	agregar=True
	trabajadoress = Trabajador.objects.filter(plaza_ocupa__departamento__unidad = request.session['unidad']).annotate(have=Count('perfil__trabajador'))

	unidades_sub= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	destinatarios = []
	destinatarios.append(Perfil.objects.get(user=request.session['userid']).trabajador)
	for trabajador in trabajadoress:
		for unidad_sub in unidades_sub:
			if trabajador.plaza_ocupa.departamento.unidad==unidad_sub and trabajador.have == 1:
				destinatarios.append(trabajador)
		if str(trabajador.plaza_ocupa.departamento.unidad.id)==str(request.session['unidad']) and str(trabajador.id) != str(request.session['trabajador'])and trabajador.have == 1:
				destinatarios.append(trabajador)

	if request.method=='POST':
		usuario = Perfil.objects.get(trabajador=request.POST['select2'])
		
		tar = Tarea.objects.filter(responsable=usuario.trabajador.id, fini__gte=menostres, ffin__lte=mastres)
		
		tar_participantes = Tarea.objects.filter(participantes=usuario.trabajador.id, fini__gte=menostres, ffin__lte=mastres)
		
		trabajadores = Trabajador.objects.filter(plaza_ocupa__departamento__unidad = request.session['unidad']).order_by('-id')
		
		if str(usuario.user.id) != str(request.session['userid']):
			agregar=False
	else:
		usuario = Perfil.objects.get(user=request.session['userid'])

		tar = Tarea.objects.filter(responsable=usuario.trabajador.id, fini__gte=menostres, ffin__lte=mastres)
		tar_participantes = Tarea.objects.filter(participantes=usuario.trabajador.id, fini__gte=menostres, ffin__lte=mastres)
		trabajadores = Trabajador.objects.filter(plaza_ocupa__departamento__unidad = request.session['unidad']).order_by('-id')

	return render_to_response('tareas/calendario.html',{'agregar':agregar,'trabajadores':trabajadores, 'tar_participantes':tar_participantes, 'tar':tar, 'ano':ano, 'usuario':usuario, 'destinatarios':destinatarios} , context_instance=RequestContext(request))











@login_required(login_url='/ingresar')
def info_tareas(request):
	id_trabajador=str(request.session['trabajador'])

	id_tarea = request.GET.get('id')
	tar = Tarea.objects.get(id=id_tarea)
	trabajador = Trabajador.objects.get(id=tar.responsable)
	return render_to_response('tareas/info.tarea.html',{'tar':tar,'trabajador':trabajador,'id_trabajador':id_trabajador} , context_instance=RequestContext(request))














@login_required(login_url='/ingresar')
def agregar_tarea(request):
	usuario = Perfil.objects.get(user=request.session['userid'])

	trabajadoress = Trabajador.objects.all()
	unidades_sub= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	participantes = []
	for trabajador in trabajadoress:
		for unidad_sub in unidades_sub:
			if trabajador.plaza_ocupa.departamento.unidad==unidad_sub:
				participantes.append(trabajador)
		if str(trabajador.plaza_ocupa.departamento.unidad.id)==str(request.session['unidad']) and str(trabajador.id) != str(request.session['trabajador']):
			participantes.append(trabajador)

	if request.method=='POST':
		dias = 0

		p = request.POST.get('participantes')
		f = request.POST.get('fechas')

		arreglado = f.split("/")
		a = "-".join(arreglado)


		comparafini = a[17:18]
		if comparafini == "P":
			g=int(a[11:13])
			if g == 12:
				suma = g
			else:
				suma = g + 12
			fini = a[0:11] + str(suma) + a[13:16]
		else:
			fini = a[0:16]


		comparaffin = a[43:44]
		if comparaffin == "P":
			g=int(a[37:39])
			if g == 12:
				suma = g
			else:
				suma = g + 12
			ffin = a[26:37] + str(suma) + a[39:42]
		else:
			ffin = a[26:42]



		form_tarea = Formulario_Tareas(request.POST)

		t = str(request.POST.get('frecuencia'))



		if str(t)==str(100):
			x = 1
		else:
			x = int(request.POST.get('tiempo'))




		if request.POST.get('frecuencia') == 'semanal':
			dias = 7
			x = x * 4
		elif request.POST.get('frecuencia') == 'quincenal':
			dias = 14
			x = x * 2
		elif request.POST.get('frecuencia') == 'mensual' or  '' :
			dias = 28
			x = x * 1

		while x > 0:

			form_tarea = Formulario_Tareas(request.POST)
			if form_tarea.is_valid():

				form = form_tarea.save(commit=False)
				form.fini = fini
				form.ffin = ffin
				form.responsable = usuario.trabajador.id
				form.activo = True
				form.save()
				form_tarea.save_m2m()

				d = request.POST.get('deficiencia')
				if d !='nada':
					deficiencia = Deficiencia.objects.get(id=d)
					deficiencia_tarea = deficienciasXtareas()
					deficiencia_tarea.tarea=form
					deficiencia_tarea.deficiencia=deficiencia
					deficiencia_tarea.save()
				acciones="La tarea "+ form.tarea + "programada del " + str(form.fini)+ " al "+ str(form.ffin)+ " fue agregada"
				registrar_log(request,acciones,2)




			if x > 0:
				x = int(x) - int(1)

				anno = int(fini[0:4])
				mes = int(fini[5:7])
				dia = int(fini[8:10])
				hora = fini[11:13]
				minuto = fini[14:17]


				fini = datetime(anno, mes, dia, int(hora), int(minuto)).date() + timedelta(days=dias)
				fini =  str(fini)+ " " + str(hora) + ":" + str(minuto)



				anno1 = int(ffin[0:4])
				mes1 = int(ffin[5:7])
				dia1 = int(ffin[8:10])
				hora1 = ffin[11:13]
				minuto1 = ffin[14:17]


				ffin = datetime(anno1, mes1, dia1, int(hora1), int(minuto1)).date() + timedelta(days=dias)
				ffin =  str(ffin)+ " " + str(hora1) + ":" + str(minuto1)

			else:
				break



		return HttpResponseRedirect('/tareas')
	else:
		form_tarea = Formulario_Tareas()
		form_tarea.fields['categoria'].initial=Nom_Categoria_Tarea.objects.get(id=4)
		form_tarea.fields['clasificacion'].initial=Nom_Clasificacion_Tarea.objects.get(id=1)
		form_tarea.fields['prioridad'].initial=Nom_Prioridad_Tarea.objects.get(id=2)
		form_tarea.fields['estado'].initial=Nom_Estado_Tarea.objects.get(id=2)
		deficiencias = Deficiencia.objects.filter(visita__unidad=request.session['unidad'], estado__estado='Detectado')
	return render_to_response('tareas/agregar_tarea.html',{'deficiencias':deficiencias,'participantes':participantes, 'form_tarea':form_tarea} , context_instance=RequestContext(request))








@login_required(login_url='/ingresar')
def editar_tarea(request):
	usuario = Perfil.objects.get(user=request.session['userid'])
	id_tarea = request.GET.get('id')
	tar_edit=Tarea.objects.get(id=id_tarea)

	if int(tar_edit.fini.strftime("%H%m")) > 1200:
		tiempoini=" PM"
	else:
		tiempoini=" AM"

	if int(tar_edit.ffin.strftime("%H%m")) > 1200:
		tiempofin=" PM"
	else:
		tiempofin=" AM"

	fecha= tar_edit.fini.strftime("%Y-%m-%d %I:%M %p") + " hasta " + tar_edit.ffin.strftime("%Y-%m-%d %I:%M %p")






	trabajadoress = Trabajador.objects.all()
	unidades_sub= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	participantes = []
	for trabajador in trabajadoress:
		for unidad_sub in unidades_sub:
			if trabajador.plaza_ocupa.departamento.unidad==unidad_sub:
				participantes.append(trabajador)
		if str(trabajador.plaza_ocupa.departamento.unidad.id)==str(request.session['unidad']) and str(trabajador.id) != str(request.session['trabajador']):
			participantes.append(trabajador)



	if request.method=='POST':
		p = request.POST.get('participantes')

		f = request.POST.get('fechas')
		arreglado = f.split("/")
		a = "-".join(arreglado)


		comparafini = a[17:18]
		if comparafini == "P":
			g=int(a[11:13])
			if g == 12:
				suma = g
			else:
				suma = g + 12
			fini = a[0:11] + str(suma) + a[13:16]
		else:
			fini = a[0:16]


		comparaffin = a[43:44]
		if comparaffin == "P":
			g=int(a[37:39])
			if g == 12:
				suma = g
			else:
				suma = g + 12
			ffin = a[26:37] + str(suma) + a[39:42]
		else:
			ffin = a[26:42]


		form_tarea = Formulario_Tareas(request.POST)

		tar=Tarea.objects.all()

		if form_tarea.is_valid():
			form = form_tarea.save(commit=False)
			form.fini = fini
			form.ffin = ffin
			form.responsable = usuario.trabajador.id
			form.activo = True
			form.save()
			form_tarea.save_m2m()
			acciones="La tarea "+ form.tarea + "programada del " + str(form.fini)+ " al "+ str(form.ffin)+ " fue editada"
			registrar_log(request,acciones,2)

			d = request.POST.get('deficiencia')
			if d !='nada':
				deficiencia = Deficiencia.objects.get(id=d)
				deficiencia_tarea = deficienciasXtareas()
				deficiencia_tarea.tarea=form
				deficiencia_tarea.deficiencia=deficiencia
				deficiencia_tarea.save()
			tar_edit.delete()
			return HttpResponseRedirect('/tareas')
	else:
		form_tarea = Formulario_Tareas(instance=tar_edit)
		deficiencias = Deficiencia.objects.filter(visita__unidad=request.session['unidad'], estado__estado='Detectado')
	return render_to_response('tareas/agregar_tarea.html',{'deficiencias':deficiencias, 'participantes':participantes, 'form_tarea':form_tarea, 'tar_edit':tar_edit,'fecha':fecha} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_tarea(request):
	id_tarea = request.GET.get('id')
	tarea = Tarea.objects.get(id=id_tarea)
	tarea.delete()
	acciones="La tarea "+ tarea.tarea + "programada del " + str(tarea.fini)+ " al "+ str(tarea.ffin)+ " fue eliminada"
	registrar_log(request,acciones,3)
	return HttpResponseRedirect('/tareas')























from reportlab.pdfgen import *
from django.http import HttpResponse

@login_required(login_url='/ingresar')
class IndexView(ListView):
	template_name = "index.html"
	model = Tarea
	context_object_name = "t"





def exportarlarga(request):
	if request.POST:
		mes = int(request.POST.get('mes'))
		ano = int(request.POST.get('anno'))
		usuario = Trabajador.objects.get(id=request.POST.get('usua'))
	else:
		mes = int(request.GET.get('mes'))
		ano = int(request.GET.get('anno'))
		usuario = Trabajador.objects.get(id=request.GET.get('usuario'))
	if mes == 1:
		descmes='Enero'
	if mes == 2:
		descmes='Febrero'
	if mes == 3:
		descmes='Marzo'
	if mes == 4:
		descmes='Abril'
	if mes == 5:
		descmes='Mayo'
	if mes == 6:
		descmes='Junio'
	if mes == 7:
		descmes='Juli'
	if mes == 8:
		descmes='Agosto'
	if mes == 9:
		descmes='Septiembre'
	if mes == 10:
		descmes='Octubre'
	if mes == 11:
		descmes='Noviembre'
	if mes == 12:
		descmes='Diciembre'


	desde="1-%s-%s" % (mes, ano)
	hasta="%s" % (calendar.monthrange(ano, mes)[1])

#~ dia de la semana (del 1 al 7)  referenciando de lunes-1 a domingo-7
	primerdiasemana=datetime(ano,mes,1).strftime('%w')

	if primerdiasemana=='0':
		primerdiasemana='7'

	dias=[1,2,3,4,5,6,7]

	response = HttpResponse(content_type='application/pdf')
	pdf_name = "Tareas.pdf"

	buff = BytesIO()

	doc = SimpleDocTemplate(buff,
							pagesize=landscape(letter),
							rightMargin=50,
							leftMargin=50,
							topMargin=15,
							bottomMargin=15,
							)

	tareas=[]
	styles = getSampleStyleSheet()
	styleSheet = getSampleStyleSheet()

#~ Portada
	I = Image(os.path.join(BASE_DIR, 'Proyecto/static/esculapio.png'))

    

	I.drawHeight = 0.80*inch*I.drawHeight / I.drawWidth
	I.drawWidth = 0.80*inch

	Un = Paragraph('''<para align=center><font size=14 ><b>'''+usuario.plaza_ocupa.departamento.unidad.nombre+'''</b></font></para>''',styleSheet["BodyText"])
	Mu = Paragraph('''<para align=center><font size=12 ><b>'''+usuario.plaza_ocupa.departamento.unidad.municipio.municipio+'''</b></font></para>''',styleSheet["BodyText"])
	T = Paragraph('''<para align=center><font size=16 ><b>Plan de trabajo para '''+descmes+''' del '''+str(ano)+ '''</b></font></para>''',styleSheet["BodyText"])
	E = Paragraph('''<para align=left><b>Elaborado:</b></para>''',styleSheet["BodyText"])
	Ap = Paragraph('''<para align=center><font size=10>'''+usuario.nombre+' ''</font></para>''',styleSheet["BodyText"])
	#Ac = Paragraph('''<para align=center><font size=10>'''+usuario.plaza_ocupa.plaza+'''</font></para>''',styleSheet["BodyText"])
	A = Paragraph('''<para align=left><b>Aprobado:</b></para>''',styleSheet["BodyText"])
	Pr = Paragraph('''<para align=left><font size=12 ><b>Principles tareas: </b></font></para>''',styleSheet["BodyText"])

	Unidad= [
		[''],
		[Un]
		]
	img= [
		['','',''],
		['',[I],'']
		]

	enc= [
		['','',''],
		['','',''],
		[[E],'',[A],],
		[[Ap],'','       ______________________________',],
		#[[Ac],'','       ______________________________',],
		['','',''],
		['','','']
		]

	Un = Table(Unidad)
	tareas.append(Un)
	tareas.append(Mu)
	IMG = Table(img)
	tareas.append(IMG)
	tareas.append(T)

	U = Table(enc)
	tareas.append(U)
	tareas.append(Pr)

#~ Tareas Principales
	p={}
	fecha1=datetime(ano,mes,1)
	fecha2= datetime(ano,mes,int(hasta),23,59,59)
#~ Seleccionando las tareas de Alta Prioridad
	tars = Tarea.objects.filter(Q(responsable=usuario.id, prioridad__prioridad='Alta', fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, prioridad__prioridad='Alta', fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
	u=0
	for tar in tars:
		u=u+1
		p=Paragraph(str(u)+'- '+tar.tarea,styleSheet["BodyText"])
		tareas.append(p)

#~ /Tareas Principales
	tareas.append(CondPageBreak(500))
#~ /Portada

	datos={}
	D={}
	contador=1
#~ PRIMERA SEMANA
	for dia in dias:
		if dia>=int(primerdiasemana):
			fecha1=datetime(ano,mes,contador)
			fecha2= datetime(ano,mes,contador,23,59,59)
			tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
			datos[dia]=''
			for tar in tars:
				if int(tar.fini.strftime('%d')) == contador:
					hora=tar.fini.strftime('%I:%M %p')
				else:
					hora='cont.'
				datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
			D[dia]=contador
			contador=1+contador
		else:
			datos[dia]=''
			D[dia]=''
	headings1 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sáqbado '+str(D[6]),'Domingo '+str(D[7])]]
	semana1=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]

#~ SEGUNDA SEMANA
	for dia in dias:
		fecha1=datetime(ano,mes,contador)
		fecha2= datetime(ano,mes,contador,23,59,59)
		tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
		datos[dia]=''
		for tar in tars:
			if int(tar.fini.strftime('%d')) == contador:
				hora=tar.fini.strftime('%I:%M %p')
			else:
				hora='cont.'
			datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
		D[dia]=contador
		contador=1+contador
	headings2 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
	semana2=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]

#~ TERCERA SEMANA
	for dia in dias:
		fecha1=datetime(ano,mes,contador)
		fecha2= datetime(ano,mes,contador,23,59,59)
		tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
		datos[dia]=''
		for tar in tars:
			if int(tar.fini.strftime('%d')) == contador:
				hora=tar.fini.strftime('%I:%M %p')
			else:
				hora='cont.'
			datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
		D[dia]=contador
		contador=1+contador
	headings3 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
	semana3=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]


#~ CUARTA SEMANA
	for dia in dias:
		fecha1=datetime(ano,mes,contador)
		fecha2= datetime(ano,mes,contador,23,59,59)
		tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
		datos[dia]=''
		for tar in tars:
			if int(tar.fini.strftime('%d')) == contador:
				hora=tar.fini.strftime('%I:%M %p')
			else:
				hora='cont.'
			datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
		D[dia]=contador
		contador=1+contador
	headings4 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
	semana4=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]









	if hasta=='31':
		if primerdiasemana== '6' or '7':

		#~ QUINTA SEMANA
			for dia in dias:
				fecha1=datetime(ano,mes,contador)
				fecha2= datetime(ano,mes,contador,23,59,59)
				tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
				datos[dia]=''
				for tar in tars:
					if int(tar.fini.strftime('%d')) == contador:
						hora=tar.fini.strftime('%I:%M %p')
					else:
						hora='cont.'
					datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
				D[dia]=contador
				contador=1+contador
			headings5 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
			semana5=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]

			#~  ULTIMA SEMANA
			for dia in dias:
				if contador<=int(hasta):
					fecha1=datetime(ano,mes,contador)
					fecha2= datetime(ano,mes,contador,23,59,59)
					tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
					datos[dia]=''
					for tar in tars:
						if int(tar.fini.strftime('%d')) == contador:
							hora=tar.fini.strftime('%I:%M %p')
						else:
							hora='cont.'
						datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''

					D[dia]=contador
					contador=1+contador
				else:
					datos[dia]=''
					D[dia]=''
			headings6 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
			semana6=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]

	else:

	#~  ULTIMA SEMANA
		for dia in dias:
			if contador<=int(hasta):
				fecha1=datetime(ano,mes,contador)
				fecha2= datetime(ano,mes,contador,23,59,59)
				tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
				datos[dia]=''
				for tar in tars:
					if int(tar.fini.strftime('%d')) == contador:
						hora=tar.fini.strftime('%I:%M %p')
					else:
						hora='cont.'
					datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
				D[dia]=contador
				contador=1+contador
			else:
				datos[dia]=''
				D[dia]=''
		headings6 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
		semana6=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]


	H1 = Table(headings1)
	t = Table(semana1, rowHeights=550)
	H2 = Table(headings2)
	t2= Table(semana2, rowHeights=550)
	H3 = Table(headings3)
	t3= Table(semana3, rowHeights=550)
	H4 = Table(headings4)
	t4= Table(semana4, rowHeights=550)
	if hasta=='31':
		if primerdiasemana== '6' or '7':
			H5 = Table(headings5)
			t5= Table(semana5, rowHeights=550)
			H6 = Table(headings6)
			t6= Table(semana6, rowHeights=550)
	else:
		H6 = Table(headings6)
		t6= Table(semana6, rowHeights=550)


#~ Conformando los estilos para las tablas
	t.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	H1.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	t2.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	H2.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	H3.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	t3.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)

		]
	))
	H4.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	t4.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))

	if hasta=='31':
		if primerdiasemana== '6' or '7':
			H5.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
			t5.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
			H6.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
			t6.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
	else:
		H6.setStyle(TableStyle(
			[
				('GRID', (0, 0), (-1, -1), 0.5, colors.black),
				('VALIGN',(0,0),(-1,-1),'TOP'),
				('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
			]
		))
		t6.setStyle(TableStyle(
			[
				('GRID', (0, 0), (-1, -1), 0.5, colors.black),
				('VALIGN',(0,0),(-1,-1),'TOP'),
				('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
			]
		))


#~ Esableciendo formato fijo para las celdas
	H1._argW[0]=1.5*inch
	H1._argW[1]=1.5*inch
	H1._argW[2]=1.5*inch
	H1._argW[3]=1.5*inch
	H1._argW[4]=1.5*inch
	H1._argW[5]=1.5*inch
	H1._argW[6]=1.5*inch

	H2._argW[0]=1.5*inch
	H2._argW[1]=1.5*inch
	H2._argW[2]=1.5*inch
	H2._argW[3]=1.5*inch
	H2._argW[4]=1.5*inch
	H2._argW[5]=1.5*inch
	H2._argW[6]=1.5*inch

	H3._argW[0]=1.5*inch
	H3._argW[1]=1.5*inch
	H3._argW[2]=1.5*inch
	H3._argW[3]=1.5*inch
	H3._argW[4]=1.5*inch
	H3._argW[5]=1.5*inch
	H3._argW[6]=1.5*inch

	H4._argW[0]=1.5*inch
	H4._argW[1]=1.5*inch
	H4._argW[2]=1.5*inch
	H4._argW[3]=1.5*inch
	H4._argW[4]=1.5*inch
	H4._argW[5]=1.5*inch
	H4._argW[6]=1.5*inch

	if hasta=='31':
		if primerdiasemana== '6' or '7':

			H5._argW[0]=1.5*inch
			H5._argW[1]=1.5*inch
			H5._argW[2]=1.5*inch
			H5._argW[3]=1.5*inch
			H5._argW[4]=1.5*inch
			H5._argW[5]=1.5*inch
			H5._argW[6]=1.5*inch

			H6._argW[0]=1.5*inch
			H6._argW[1]=1.5*inch
			H6._argW[2]=1.5*inch
			H6._argW[3]=1.5*inch
			H6._argW[4]=1.5*inch
			H6._argW[5]=1.5*inch
			H6._argW[6]=1.5*inch

	else:
		H6._argW[0]=1.5*inch
		H6._argW[1]=1.5*inch
		H6._argW[2]=1.5*inch
		H6._argW[3]=1.5*inch
		H6._argW[4]=1.5*inch
		H6._argW[5]=1.5*inch
		H6._argW[6]=1.5*inch

#~ Encabezados

#~ Tareas
	t._argW[0]=1.5*inch
	t._argW[1]=1.5*inch
	t._argW[2]=1.5*inch
	t._argW[3]=1.5*inch
	t._argW[4]=1.5*inch
	t._argW[5]=1.5*inch
	t._argW[6]=1.5*inch

	t2._argW[0]=1.5*inch
	t2._argW[1]=1.5*inch
	t2._argW[2]=1.5*inch
	t2._argW[3]=1.5*inch
	t2._argW[4]=1.5*inch
	t2._argW[5]=1.5*inch
	t2._argW[6]=1.5*inch

	t3._argW[0]=1.5*inch
	t3._argW[1]=1.5*inch
	t3._argW[2]=1.5*inch
	t3._argW[3]=1.5*inch
	t3._argW[4]=1.5*inch
	t3._argW[5]=1.5*inch
	t3._argW[6]=1.5*inch

	t4._argW[0]=1.5*inch
	t4._argW[1]=1.5*inch
	t4._argW[2]=1.5*inch
	t4._argW[3]=1.5*inch
	t4._argW[4]=1.5*inch
	t4._argW[5]=1.5*inch
	t4._argW[6]=1.5*inch

	if hasta=='31':
		if primerdiasemana== '6' or '7':

			t5._argW[0]=1.5*inch
			t5._argW[1]=1.5*inch
			t5._argW[2]=1.5*inch
			t5._argW[3]=1.5*inch
			t5._argW[4]=1.5*inch
			t5._argW[5]=1.5*inch
			t5._argW[6]=1.5*inch

			t6._argW[0]=1.5*inch
			t6._argW[1]=1.5*inch
			t6._argW[2]=1.5*inch
			t6._argW[3]=1.5*inch
			t6._argW[4]=1.5*inch
			t6._argW[5]=1.5*inch
			t6._argW[6]=1.5*inch

	else:
		t6._argW[0]=1.5*inch
		t6._argW[1]=1.5*inch
		t6._argW[2]=1.5*inch
		t6._argW[3]=1.5*inch
		t6._argW[4]=1.5*inch
		t6._argW[5]=1.5*inch
		t6._argW[6]=1.5*inch


	tareas.append(H1)
	tareas.append(t)
	#~ tareas.append(PageBreak())
	tareas.append(H2)
	tareas.append(t2)
	#~ tareas.append(PageBreak())
	tareas.append(H3)
	tareas.append(t3)
	#~ tareas.append(PageBreak())
	tareas.append(H4)
	tareas.append(t4)
	if hasta=='31':
		if primerdiasemana== '6' or '7':
			#~ tareas.append(PageBreak())
			tareas.append(H5)
			tareas.append(t5)

			#~ tareas.append(PageBreak())
			tareas.append(H6)
			tareas.append(t6)
	else:
		#~ tareas.append(PageBreak())
		tareas.append(H6)
		tareas.append(t6)


	doc.build(tareas)
	response.write(buff.getvalue())
	buff.close()
	return response













def exportarcorta(request):
	if request.POST:
		mes = int(request.POST.get('mes'))
		ano = int(request.POST.get('anno'))
		usuario = Trabajador.objects.get(id=request.POST.get('usua'))
	else:
		mes = int(request.GET.get('mes'))
		ano = int(request.GET.get('anno'))
		usuario = Trabajador.objects.get(id=request.GET.get('usuario'))
	if mes == 1:
		descmes='Enero'
	if mes == 2:
		descmes='Febrero'
	if mes == 3:
		descmes='Marzo'
	if mes == 4:
		descmes='Abril'
	if mes == 5:
		descmes='Mayo'
	if mes == 6:
		descmes='Junio'
	if mes == 7:
		descmes='Juli'
	if mes == 8:
		descmes='Agosto'
	if mes == 9:
		descmes='Septiembre'
	if mes == 10:
		descmes='Octubre'
	if mes == 11:
		descmes='Noviembre'
	if mes == 12:
		descmes='Diciembre'


	desde="1-%s-%s" % (mes, ano)
	hasta="%s" % (calendar.monthrange(ano, mes)[1])

#~ dia de la semana (del 1 al 7)  referenciando de lunes-1 a domingo-7
	primerdiasemana=datetime(ano,mes,1).strftime('%w')

	if primerdiasemana=='1':
		primerdiasemana='7'

	dias=[1,2,3,4,5,6,7]

	response = HttpResponse(content_type='application/pdf')
	pdf_name = "Tareas.pdf"

	buff = BytesIO()

	doc = SimpleDocTemplate(buff,
							pagesize=landscape(letter),
							rightMargin=50,
							leftMargin=50,
							topMargin=15,
							bottomMargin=15,
							)

	tareas=[]
	styles = getSampleStyleSheet()
	styleSheet = getSampleStyleSheet()

#~ Portada
	I = Image(os.path.join(BASE_DIR, 'Proyecto/static/esculapio.png'))

    

	I.drawHeight = 0.80*inch*I.drawHeight / I.drawWidth
	I.drawWidth = 0.80*inch

	Un = Paragraph('''<para align=center><font size=14 ><b>'''+usuario.plaza_ocupa.departamento.unidad.nombre+'''</b></font></para>''',styleSheet["BodyText"])
	Mu = Paragraph('''<para align=center><font size=12 ><b>'''+usuario.plaza_ocupa.departamento.unidad.municipio.municipio+'''</b></font></para>''',styleSheet["BodyText"])
	T = Paragraph('''<para align=center><font size=16 ><b>Plan de trabajo para '''+descmes+''' del '''+str(ano)+ '''</b></font></para>''',styleSheet["BodyText"])
	E = Paragraph('''<para align=left><b>Elaborado:</b></para>''',styleSheet["BodyText"])
	Ap = Paragraph('''<para align=center><font size=10>'''+usuario.nombre+' ''</font></para>''',styleSheet["BodyText"])
	#Ac = Paragraph('''<para align=center><font size=10>'''+usuario.plaza_ocupa.plaza+'''</font></para>''',styleSheet["BodyText"])
	A = Paragraph('''<para align=left><b>Aprobado:</b></para>''',styleSheet["BodyText"])
	Pr = Paragraph('''<para align=left><font size=12 ><b>Principles tareas: </b></font></para>''',styleSheet["BodyText"])

	Unidad= [
		[''],
		[Un]
		]
	img= [
		['','',''],
		['',[I],'']
		]

	enc= [
		['','',''],
		['','',''],
		[[E],'',[A],],
		[[Ap],'','       ______________________________',],
		#[[Ac],'','       ______________________________',],
		['','',''],
		['','','']
		]

	Un = Table(Unidad)
	tareas.append(Un)
	tareas.append(Mu)
	IMG = Table(img)
	tareas.append(IMG)
	tareas.append(T)

	U = Table(enc)
	tareas.append(U)
	tareas.append(Pr)

#~ Tareas Principales
	p={}
	fecha1=datetime(ano,mes,1)
	fecha2= datetime(ano,mes,int(hasta),23,59,59)
#~ Seleccionando las tareas de Alta Prioridad
	tars = Tarea.objects.filter(Q(responsable=usuario.id, prioridad__prioridad='Alta', fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, prioridad__prioridad='Alta', fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
	u=0
	for tar in tars:
		u=u+1
		p=Paragraph(str(u)+'- '+tar.tarea,styleSheet["BodyText"])
		tareas.append(p)

#~ /Tareas Principales
	tareas.append(CondPageBreak(500))
#~ /Portada

	datos={}
	D={}
	contador=1
#~ PRIMERA SEMANA
	for dia in dias:
		if dia>=int(primerdiasemana):
			fecha1=datetime(ano,mes,contador)
			fecha2= datetime(ano,mes,contador,23,59,59)
			tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
			datos[dia]=''
			for tar in tars:
				if int(tar.fini.strftime('%d')) == contador:
					hora=tar.fini.strftime('%I:%M %p')
				else:
					hora='cont.'
				datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
			D[dia]=contador
			contador=1+contador
		else:
			datos[dia]=''
			D[dia]=''
	headings1 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
	semana1=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]
	print contador

#~ SEGUNDA SEMANA
	for dia in dias:
		fecha1=datetime(ano,mes,contador)
		fecha2= datetime(ano,mes,contador,23,59,59)
		tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
		datos[dia]=''
		for tar in tars:
			if int(tar.fini.strftime('%d')) == contador:
				hora=tar.fini.strftime('%I:%M %p')
			else:
				hora='cont.'
			datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
		D[dia]=contador
		contador=1+contador
	headings2 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
	semana2=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]
	print contador

#~ TERCERA SEMANA
	for dia in dias:
		fecha1=datetime(ano,mes,contador)
		fecha2= datetime(ano,mes,contador,23,59,59)
		tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
		datos[dia]=''
		for tar in tars:
			if int(tar.fini.strftime('%d')) == contador:
				hora=tar.fini.strftime('%I:%M %p')
			else:
				hora='cont.'
			datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
		D[dia]=contador
		contador=1+contador
	headings3 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
	semana3=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]

	print contador

#~ CUARTA SEMANA
	for dia in dias:
		fecha1=datetime(ano,mes,contador)
		fecha2= datetime(ano,mes,contador,23,59,59)
		tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
		datos[dia]=''
		for tar in tars:
			if int(tar.fini.strftime('%d')) == contador:
				hora=tar.fini.strftime('%I:%M %p')
			else:
				hora='cont.'
			datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
		D[dia]=contador
		contador=1+contador
	headings4 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
	semana4=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]


	print contador

	if hasta=='31':
		if primerdiasemana== '6' or '7':
			for dia in dias:
				if contador<=int(hasta):
					fecha1=datetime(ano,mes,contador)
					fecha2= datetime(ano,mes,contador,23,59,59)
					tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
					datos[dia]=''
					for tar in tars:
						if int(tar.fini.strftime('%d')) == contador:
							hora=tar.fini.strftime('%I:%M %p')
						else:
							hora='cont.'
						datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''

					D[dia]=contador
					contador=1+contador
				else:
					datos[dia]=''
					D[dia]=''
			headings5 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
			semana5=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]
			print contador

			#~  ULTIMA SEMANA
			for dia in dias:
				if contador<=int(hasta):
					fecha1=datetime(ano,mes,contador)
					fecha2= datetime(ano,mes,contador,23,59,59)
					tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
					datos[dia]=''
					for tar in tars:
						if int(tar.fini.strftime('%d')) == contador:
							hora=tar.fini.strftime('%I:%M %p')
						else:
							hora='cont.'
						datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''

					D[dia]=contador
					contador=1+contador
				else:
					datos[dia]=''
					D[dia]=''
			headings6 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
			semana6=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]
			print contador

	else:

	#~  ULTIMA SEMANA
		for dia in dias:
			if contador<=int(hasta):
				fecha1=datetime(ano,mes,contador)
				fecha2= datetime(ano,mes,contador,23,59,59)
				tars = Tarea.objects.filter (Q(responsable=usuario.id, fini__lte=fecha2, ffin__gte=fecha1) | Q(participantes=usuario.id, fini__lte=fecha2, ffin__gte=fecha1)).distinct().order_by('fini')
				datos[dia]=''
				for tar in tars:
					if int(tar.fini.strftime('%d')) == contador:
						hora=tar.fini.strftime('%I:%M %p')
					else:
						hora='cont.'
					datos[dia]=datos[dia]+' '+'''<font size=10><b>'''+hora+ '''</b></font>'''+' '+'''<font size=10>'''+tar.tarea+ '''</font><br></br><br></br>'''
				D[dia]=contador
				contador=1+contador
			else:
				datos[dia]=''
				D[dia]=''
		print contador
		headings6 = [['Lunes '+str(D[1]), 'Martes '+str(D[2]), 'Miércoles '+str(D[3]),'Jueves '+str(D[4]),'Viernes '+str(D[5]),'Sábado '+str(D[6]),'Domingo '+str(D[7])]]
		semana6=	[[Paragraph(datos[1],styleSheet["BodyText"]),Paragraph(datos[2],styleSheet["BodyText"]),Paragraph(datos[3],styleSheet["BodyText"]),Paragraph(datos[4],styleSheet["BodyText"]),Paragraph(datos[5],styleSheet["BodyText"]),Paragraph(datos[6],styleSheet["BodyText"]),Paragraph(datos[7],styleSheet["BodyText"])]]


	H1 = Table(headings1)
	t = Table(semana1, rowHeights=None)
	H2 = Table(headings2)
	t2= Table(semana2, rowHeights=None)
	H3 = Table(headings3)
	t3= Table(semana3, rowHeights=None)
	H4 = Table(headings4)
	t4= Table(semana4, rowHeights=None)
	if hasta=='31':
		if primerdiasemana== '6' or '7':
			H5 = Table(headings5)
			t5= Table(semana5, rowHeights=None)
			H6 = Table(headings6)
			t6= Table(semana6, rowHeights=None)
	else:
		H6 = Table(headings6)
		t6= Table(semana6, rowHeights=None)


#~ Conformando los estilos para las tablas
	t.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	H1.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	t2.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	H2.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	H3.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	t3.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)

		]
	))
	H4.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))
	t4.setStyle(TableStyle(
		[
			('GRID', (0, 0), (-1, -1), 0.5, colors.black),
			('VALIGN',(0,0),(-1,-1),'TOP'),
			('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
		]
	))

	if hasta=='31':
		if primerdiasemana== '6' or '7':
			H5.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
			t5.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
			H6.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
			t6.setStyle(TableStyle(
				[
					('GRID', (0, 0), (-1, -1), 0.5, colors.black),
					('VALIGN',(0,0),(-1,-1),'TOP'),
					('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
				]
			))
	else:
		H6.setStyle(TableStyle(
			[
				('GRID', (0, 0), (-1, -1), 0.5, colors.black),
				('VALIGN',(0,0),(-1,-1),'TOP'),
				('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
			]
		))
		t6.setStyle(TableStyle(
			[
				('GRID', (0, 0), (-1, -1), 0.5, colors.black),
				('VALIGN',(0,0),(-1,-1),'TOP'),
				('LINEBELOW', (0, 0), (-1, 0), 2, colors.black)
			]
		))


#~ Esableciendo formato fijo para las celdas
	H1._argW[0]=1.5*inch
	H1._argW[1]=1.5*inch
	H1._argW[2]=1.5*inch
	H1._argW[3]=1.5*inch
	H1._argW[4]=1.5*inch
	H1._argW[5]=1.5*inch
	H1._argW[6]=1.5*inch

	H2._argW[0]=1.5*inch
	H2._argW[1]=1.5*inch
	H2._argW[2]=1.5*inch
	H2._argW[3]=1.5*inch
	H2._argW[4]=1.5*inch
	H2._argW[5]=1.5*inch
	H2._argW[6]=1.5*inch

	H3._argW[0]=1.5*inch
	H3._argW[1]=1.5*inch
	H3._argW[2]=1.5*inch
	H3._argW[3]=1.5*inch
	H3._argW[4]=1.5*inch
	H3._argW[5]=1.5*inch
	H3._argW[6]=1.5*inch

	H4._argW[0]=1.5*inch
	H4._argW[1]=1.5*inch
	H4._argW[2]=1.5*inch
	H4._argW[3]=1.5*inch
	H4._argW[4]=1.5*inch
	H4._argW[5]=1.5*inch
	H4._argW[6]=1.5*inch

	if hasta=='31':
		if primerdiasemana== '6' or '7':

			H5._argW[0]=1.5*inch
			H5._argW[1]=1.5*inch
			H5._argW[2]=1.5*inch
			H5._argW[3]=1.5*inch
			H5._argW[4]=1.5*inch
			H5._argW[5]=1.5*inch
			H5._argW[6]=1.5*inch

			H6._argW[0]=1.5*inch
			H6._argW[1]=1.5*inch
			H6._argW[2]=1.5*inch
			H6._argW[3]=1.5*inch
			H6._argW[4]=1.5*inch
			H6._argW[5]=1.5*inch
			H6._argW[6]=1.5*inch

	else:
		H6._argW[0]=1.5*inch
		H6._argW[1]=1.5*inch
		H6._argW[2]=1.5*inch
		H6._argW[3]=1.5*inch
		H6._argW[4]=1.5*inch
		H6._argW[5]=1.5*inch
		H6._argW[6]=1.5*inch

#~ Encabezados

#~ Tareas
	t._argW[0]=1.5*inch
	t._argW[1]=1.5*inch
	t._argW[2]=1.5*inch
	t._argW[3]=1.5*inch
	t._argW[4]=1.5*inch
	t._argW[5]=1.5*inch
	t._argW[6]=1.5*inch

	t2._argW[0]=1.5*inch
	t2._argW[1]=1.5*inch
	t2._argW[2]=1.5*inch
	t2._argW[3]=1.5*inch
	t2._argW[4]=1.5*inch
	t2._argW[5]=1.5*inch
	t2._argW[6]=1.5*inch

	t3._argW[0]=1.5*inch
	t3._argW[1]=1.5*inch
	t3._argW[2]=1.5*inch
	t3._argW[3]=1.5*inch
	t3._argW[4]=1.5*inch
	t3._argW[5]=1.5*inch
	t3._argW[6]=1.5*inch

	t4._argW[0]=1.5*inch
	t4._argW[1]=1.5*inch
	t4._argW[2]=1.5*inch
	t4._argW[3]=1.5*inch
	t4._argW[4]=1.5*inch
	t4._argW[5]=1.5*inch
	t4._argW[6]=1.5*inch

	if hasta=='31':
		if primerdiasemana== '6' or '7':

			t5._argW[0]=1.5*inch
			t5._argW[1]=1.5*inch
			t5._argW[2]=1.5*inch
			t5._argW[3]=1.5*inch
			t5._argW[4]=1.5*inch
			t5._argW[5]=1.5*inch
			t5._argW[6]=1.5*inch

			t6._argW[0]=1.5*inch
			t6._argW[1]=1.5*inch
			t6._argW[2]=1.5*inch
			t6._argW[3]=1.5*inch
			t6._argW[4]=1.5*inch
			t6._argW[5]=1.5*inch
			t6._argW[6]=1.5*inch

	else:
		t6._argW[0]=1.5*inch
		t6._argW[1]=1.5*inch
		t6._argW[2]=1.5*inch
		t6._argW[3]=1.5*inch
		t6._argW[4]=1.5*inch
		t6._argW[5]=1.5*inch
		t6._argW[6]=1.5*inch


	tareas.append(H1)
	tareas.append(t)
	#~ tareas.append(PageBreak())
	tareas.append(H2)
	tareas.append(t2)
	#~ tareas.append(PageBreak())
	tareas.append(H3)
	tareas.append(t3)
	#~ tareas.append(PageBreak())
	tareas.append(H4)
	tareas.append(t4)
	if hasta=='31':
		if primerdiasemana== '6' or '7':
			#~ tareas.append(PageBreak())
			tareas.append(H5)
			tareas.append(t5)

			#~ tareas.append(PageBreak())
			tareas.append(H6)
			tareas.append(t6)
	else:
		#~ tareas.append(PageBreak())
		tareas.append(H6)
		tareas.append(t6)


	doc.build(tareas)
	response.write(buff.getvalue())
	buff.close()
	return response
