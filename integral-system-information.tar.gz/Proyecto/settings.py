"""
Django settings for Proyecto project.

For more information on this file, see
https://docs.djangoproject.com/en/1.6/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.6/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
BASE_DIR = os.path.dirname(os.path.dirname(__file__))


#~ DATE_INPUT_FORMATS = ('%m/%d/%Y')


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.6/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'yl&ktcj@&bp&b-vg(an956%aood4crz9mzi&b=btwigmb+b2z9'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

TEMPLATE_CONTEXT_PROCESSORS = ("django.contrib.auth.context_processors.auth",
"django.core.context_processors.debug",
"django.core.context_processors.i18n",
"django.core.context_processors.media",
"django.core.context_processors.static",
"django.core.context_processors.tz",
"django.contrib.messages.context_processors.messages",
"django.core.context_processors.request")


TEMPLATE_DEBUG = True


ALLOWED_HOSTS = []


# Application definition

INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    #'pastebin',
    #~ 'qrcode',

    'unidad',
    'rrhh',
    'tareas',
    'mensajes',
    'equipamiento',
    'radio',
    'galeria',
    'carpeta',
    'telefonos',
    'inspeccion',
    'reporte',
    'finanzas',
    'activos',
    'transporte',
    'vigilancia',
    'presupuesto',
    #~ 'singeniero',
    'distribucion',
    'investigacion',
    'reclutamiento',
)

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)

ROOT_URLCONF = 'Proyecto.urls'

WSGI_APPLICATION = 'Proyecto.wsgi.application'


# Database
# https://docs.djangoproject.com/en/1.6/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3', # Add 'postgresql_psycopg2', 'mysql', 'sqlite3' or 'oracle'.
        'NAME': 'sii.db',                      # Or path to database file if using sqlite3.
        # The following settings are not used with sqlite3:
        'USER': '',
        'PASSWORD': '',
        'HOST': '',                      # Empty for localhost through domain sockets or '127.0.0.1' for localhost through TCP.
        'PORT': '',                      # Set to empty string for default.
    }
}


# Internationalization
# https://docs.djangoproject.com/en/1.6/topics/i18n/

LANGUAGE_CODE = 'es-es'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = False


# Absolute path to the directory static files should be collected to.
# Don't put anything in this directory yourself; store your static files
# in apps' "static/" subdirectories and in STATICFILES_DIRS.
# Example: "/var/www/example.com/static/"
STATIC_ROOT = os.path.join(BASE_DIR, 'Proyecto/comun/static_root/')

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.6/howto/static-files/

STATIC_URL = '/static/'
# Additional locations of static files
STATICFILES_DIRS = (
    # Put strings here, like "/home/html/static" or "C:/www/django/static".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    os.path.join(BASE_DIR, 'Proyecto/static'),

)

TEMPLATE_DIRS = (
    # Put strings here, like "/home/html/django_templates" or "C:/www/django/templates".
    # Always use forward slashes, even on Windows.
    # Don't forget to use absolute paths, not relative paths.
    os.path.join(BASE_DIR, 'Proyecto/comun/base'),

    os.path.join(BASE_DIR, 'rrhh/plantilla'),
    os.path.join(BASE_DIR, 'unidad/plantilla'),
    os.path.join(BASE_DIR, 'tareas/plantilla'),
    os.path.join(BASE_DIR, 'mensajes/plantilla'),
    os.path.join(BASE_DIR, 'equipamiento/plantilla'),
    os.path.join(BASE_DIR, 'radio/plantilla'),
    os.path.join(BASE_DIR, 'galeria/plantilla'),
    os.path.join(BASE_DIR, 'carpeta/plantilla'),
    os.path.join(BASE_DIR, 'telefonos/plantilla'),
    os.path.join(BASE_DIR, 'inspeccion/plantilla'),
    os.path.join(BASE_DIR, 'reporte/plantilla'),
    os.path.join(BASE_DIR, 'transporte/plantilla'),
    os.path.join(BASE_DIR, 'activos/plantilla'),
    os.path.join(BASE_DIR, 'vigilancia/plantilla'),
    os.path.join(BASE_DIR, 'presupuesto/plantilla'),
    os.path.join(BASE_DIR, 'Proyecto/comun/base'),
    os.path.join(BASE_DIR, 'singeniero/plantilla'),
    os.path.join(BASE_DIR, 'distribucion/plantilla'),
    os.path.join(BASE_DIR, 'investigacion/plantilla'),
    os.path.join(BASE_DIR, 'reclutamiento/plantilla'),



)
