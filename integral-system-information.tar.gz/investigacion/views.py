#!/usr/bin/python
# -*- coding: utf-8 -*-

from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext

from rrhh.models import *
from unidad.models import *
from unidad.views import *

from investigacion.forms import *
from investigacion.models import *



from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.db.models import Count







############################
##    CRUD publicaciones
############################

def lista_publicaciones(request):

	informe = publicaciones.objects.all()

	return render_to_response('publicaciones/publicaciones.html',{
	'informe':informe,
	}, context_instance=RequestContext(request))


def eliminar_publicaciones(request):
	id = request.GET.get('id_reporte')
	auto = publicaciones.objects.get(id=id)
	auto.delete()

	r = Userlog(usuario = request.session['userid'], unidad =  request.session['unidad'], departamento = request.session['organizativa'], trabajador = request.session['nombre'], accion = 'Elimino al elemento' + str(auto), numaccion = '3', ip = '3')
	r.save()

	return HttpResponseRedirect('/publicaciones')


def form_publicaciones(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)

	y = request.POST.get('anno')




	if request.method=='POST':
		form_publicaciones = formulario_publicaciones(request.POST, request.FILES)
		if form_publicaciones.is_valid():
			form = form_publicaciones.save(commit=False)
			form.anno = y
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/publicaciones')
	else:
		form_publicaciones = formulario_publicaciones()
	return render_to_response('publicaciones/formulario.publicaciones.html',{'form_publicaciones':form_publicaciones} , context_instance=RequestContext(request))


def editar_publicaciones(request):
	id_equipo = request.GET.get('id')
	auto = publicaciones.objects.get(id=id_equipo)
	informe = publicaciones.objects.all()
	y = request.POST.get('anno')

	if request.method=='POST':
		form_publicaciones = formulario_publicaciones(request.POST,instance=auto)
		if form_publicaciones.is_valid():
			form = form_publicaciones.save(commit=False)
			form.anno = y
			form.save()
			return HttpResponseRedirect('/publicaciones')
	else:
		form_publicaciones = formulario_publicaciones(instance=auto)
	return render_to_response('publicaciones/formulario.publicaciones.html',{'form_publicaciones':form_publicaciones,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD publicaciones
############################



