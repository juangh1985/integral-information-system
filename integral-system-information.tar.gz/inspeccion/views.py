#!/usr/bin/python
# -*- coding: latin-1 -*-
import os, sys
from django.shortcuts import render
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from tareas.models import *
from django.http import HttpResponseRedirect, HttpRequest, HttpResponse
from inspeccion.models import *
from inspeccion.forms import *
from carpeta.models import *
from django.db.models import Count
from django.db.models import Q
from datetime import *
from django.contrib.auth.decorators import login_required

import calendar
from io import BytesIO
from unidad.views import *
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Table, TableStyle,PageBreak
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, inch, landscape, portrait
from reportlab.lib.enums import TA_CENTER
from django.utils.translation import string_concat
from django.views.generic import UpdateView, ListView


@login_required(login_url='/ingresar')
def inspeccion_unidades(request):
	id_unidad_log=request.session['unidad']
	unidad_log= Unidad.objects.get(id=id_unidad_log)
	ahora = datetime.now()
	unidadestodas= Unidad.objects.all().exclude(id=request.session['unidad']).order_by('-municipio')
	unidades= []
	id_unidad=request.GET.get('id')
	unidad= Unidad.objects.get(id=id_unidad)
	permiso=comprobar_perfil(request,unidad.id)
	if permiso ==2:
		return HttpResponseRedirect('/')
	visitas= Visita.objects.filter(unidad=id_unidad)

	for unidad1 in unidadestodas:
		if len(unidad1.departamento.all())>0:
			unidades.append(unidad1)
	return render_to_response('visita/inspeccion_unidades.html',{'unidades':unidades,'ahora':ahora,'unidad':unidad,'unidad_log':unidad_log,'visitas':visitas}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def guia_inspeccion(request):
	unidad_provincial = Unidad.objects.get(id = request.session['unidad'])
	if unidad_provincial.tipo.tipo == 'Direcciones Provinciales de Salud':
		tipo = Nom_Tipo_Visita.objects.get(tipo = 'Integral Provincial')
	else:
		tipo = Nom_Tipo_Visita.objects.get(tipo = 'Integral Municipal')

	id_unidad=request.GET.get('id')
	unidad= Unidad.objects.get(id=id_unidad)
	permiso=comprobar_perfil(request,unidad.id)
	if permiso ==2 or unidad.id == request.session['unidad']:
		return HttpResponseRedirect('/') 
	anno = int(datetime.now().strftime("%Y"))
	anno_anterior=anno-1
	mes = int(datetime.now().strftime("%m"))
	dia = int(datetime.now().strftime("%d"))
	form_participantes=Formulario_Participante()
	#aki cojo la ultima visita a la unidad
	
	
	visitas1= Visita.objects.filter(unidad=unidad).order_by('-id')
	if visitas1:
		visitas = visitas1[0]
	else:
		visitas = 'false'
	
	
	#end ultima unidad
	
	#aki las deficiencias de esa visita
	if visitas != 'false':
		deficiencias = Deficiencia.objects.filter(visita__unidad = unidad, estado__estado = 'Detectado')
		fechaf=datetime(anno,mes,dia)
		deficiencias_resueltas= Deficiencia.objects.filter(visita__unidad=id_unidad, estado__estado='Erradicada', fechafin=fechaf)
	else:
		deficiencias = ''
		deficiencias_resueltas = ''
	#end deficiencias
	
	#aki los participantes de la provincia
	trabajadoress = Trabajador.objects.annotate(have=Count('perfil__trabajador'))
	dps= Unidad.objects.filter(id=request.session['unidad'])
	fecha = datetime.now()
	participantes = []
	for trabajador in trabajadoress:
		for dpsprov in dps:
			if trabajador.plaza_ocupa.departamento.unidad==dpsprov and trabajador.have == 1:
				participantes.append(trabajador)
		
	#end participantes de la provincia
	
	#aki los usuarios de la unidad
	
	unidad_visitada= Unidad.objects.filter(id=id_unidad)
	
	usuarios = []
	for trabajador in trabajadoress:
		for unidad_visitadaa in unidad_visitada:
			if trabajador.plaza_ocupa.departamento.unidad==unidad_visitadaa and trabajador.have == 1:
				usuarios.append(trabajador)
	
	#end usuarios de la unidad
	
	
	
	#AKi TAREAS DE LOS USUARIOS
	tareas = []
	contador = 0
	reuniones_fechas = []
	for usuario in usuarios:
		tarea=Tarea.objects.filter(responsable = usuario.id, fini__gte = datetime(anno, 1, 1),categoria__categoria = "Reuniones")
		contador = contador + tarea.count()
		tareas.append(tarea)
		for entity in tarea:
			reuniones_fechas.append(entity.fini)
	#END TAREAS DE LOS USUARIOS
	
	#Aki cuento las reuniones
	
	
		
	#end reuniones
	
	#Visitas del usuario
	visitas_usuario = []
	for usuario in usuarios:
		visitas_usuario.append(Visita.objects.filter(participantes = usuario.id, fecha__gte = datetime(anno, 1, 1)))
	
	#END Visitas
	
	#Aki cuento las visitas
	contador_visitas = 0
	visitas_fechas = []
	for entity in visitas_usuario:
		for entity1 in entity:
			if entity1.tipo.tipo == "Integral Municipal":
				contador_visitas = contador_visitas + 1
				visitas_fechas.append(entity1.fecha)
		
	#end visitas
	
	#print tareas
	###############################################
	######AKI COMIENZO EN LA CARPETA DE TRABAJO####
	###############################################
	#documentos oficiales solicitados
	document = Ficheros.objects.filter(unidad=id_unidad)
	#END documentos oficiales
	#documentos oficiales subidos por el usuario
	fichero = Documentos.objects.filter(documento=document, unidad =unidad)
	files = []
	for file in fichero: 
		files.append(file.documento)
	#end ficheros oficiales
	
	#objeto conectividad
	conectividad1 = Conectividad.objects.filter(unidad=unidad)
	conectividadd = conectividad1
	if conectividad1:
		conectividadd = conectividad1[0]

	#Tomando objeto enlace
	enlace = Enlaces.objects.filter(conectividad=conectividadd)
	#Tomando Paginas web
	webs = P_web.objects.filter(conectividad=conectividadd)
	
	return render_to_response('visita/guia_inspeccion.html',
	{'unidad':unidad,
	'participantes':participantes,
	'fecha':fecha,
	'anno':anno,
	'anno_anterior':anno_anterior,
	'mes': mes,
	'visitas':visitas,
	'deficiencias':deficiencias,
	'deficiencias_resueltas':deficiencias_resueltas,
	'document':document,
	'fichero':fichero,
	'files':files,
	'enlace':enlace,
	'contador_visitas':contador_visitas,
	'visitas_fechas':visitas_fechas,
	'webs':webs,
	'usuarios':usuarios,
	'contador':contador,
	'reuniones_fechas':reuniones_fechas,
	'tareas':tareas,
	'tipo':tipo,
	'id_unidad':id_unidad,
	'form_participantes':form_participantes
	}
	, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def deficiencia(request):

	if request.POST['hidden'] == "inspeccion":
		dia = int(request.POST['dia'])
		mes = int(request.POST['mes'])
		anno = int(request.POST['anno'])
		fecha1=datetime(anno,mes,dia,00,00,00)
		fecha2= datetime(anno,mes,dia,23,59,59)
		unidad1 = Unidad.objects.get(id = request.POST['unidad'])
		permiso=comprobar_perfil(request,unidad1.id)
		if permiso ==2 or unidad1.id == request.session['unidad']:
			return HttpResponseRedirect('/') 
		#Aki estamos creando una visita
		if Visita.objects.filter(unidad=unidad1.id, fecha__lte=fecha2, fecha__gte=fecha1).count()>0:
			visita=Visita.objects.get(unidad=unidad1.id, fecha__lte=fecha2, fecha__gte=fecha1)
			form_deficiencias = Formulario_Deficiencia()
			return render_to_response('deficiencias/deficiencias.html',{'form_deficiencias':form_deficiencias,'entity':visita,} , context_instance=RequestContext(request))
					
		else:

			tipo = Nom_Tipo_Visita.objects.get(tipo = request.POST['tipo'])

			form_participantes = Formulario_Participante(request.POST)
			visitado = Trabajador.objects.get(id = request.POST['visitado'])

			participantes = form_participantes['participantes'].value()

			fecha = date(anno, mes, dia)
			activo = False
			
			visita =Visita.objects.create(tipo= tipo, unidad = unidad1, fecha = fecha, visitado = visitado.nombre, activo = activo)
			for entity in participantes:
				visita.participantes.add(Trabajador.objects.get(id=entity))
			visita.save()
			#end visita
			
			#Aki Creo las deficiencias con docuemntos
			documentos_faltantes = []
			document = Ficheros.objects.filter(unidad=request.POST['unidad'])

			for i in document:
				carpetadoc = 'carpetadoc'+str(i.id)
				try: 
					request.POST[carpetadoc]
				except: 
					documento = Ficheros.objects.get(id = i.id)
					estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
					aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Carpeta de Trabajo')
					puntoaspecto = 'carpetadoc'+str(i.id)
					str_deficiencia = string_concat('Falta el documento ', documento.nombre)
					deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
					if len(deficiencia_vieja) == 0:			
						deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
						deficiencia.save()
			
			#
			#aki deficiencias con conectividad
			
			try: 
				request.POST['carpetacon']
				
			except: 
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Carpeta de Trabajo')
				puntoaspecto = 'carpetacon'
				enlace_true = Enlaces.objects.filter(conectividad__unidad = request.POST['unidad'])
				if enlace_true:
					str_deficiencia = 'Tiene mal los datos de su enlace ' 
				else:
					str_deficiencia = 'No tiene enlace insertado '
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#end conectividad
			
			#aki la planificacion
			####Reuniones de departamento
			try: 
				request.POST['planificacion1']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
				puntoaspecto = 'planificacion1'
				str_deficiencia = 'No realiza reuniones de departamento/municipio'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			### end reuniones
			
			####Actas de Acuerdos
			try: 
				request.POST['planificacion2']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
				puntoaspecto = 'planificacion2'
				str_deficiencia = 'No se realizan las actas de acuerdos'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:							
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			### end actas
			
			####Seguimiento a acuerdos
			try: 
				request.POST['planificacion3']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
				puntoaspecto = 'planificacion3'
				str_deficiencia = 'No le da seguimiento a los acuerdos tomados'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			### end seguimientos
			
			####Vistitas a unidades de subordinacion
			try: 
				request.POST['planificacion4']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
				puntoaspecto = 'planificacion4'
				str_deficiencia = 'No realiza visitas a unidaddes de subordinacion' 
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			### end seguimientos
			
			####Cumplimiento del plan de trabajo mensual
			try: 
				request.POST['planificacion5']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
				puntoaspecto = 'planificacion5'
				str_deficiencia = 'No se evalua el cumplimiento de los planes de trabajo mensual'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			### end plan
			
			####Documentan procesos planificados
			try: 
				request.POST['planificacion6']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
				puntoaspecto = 'planificacion6'
				str_deficiencia = 'No se cumplen y documentan los procesos planificados'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			### end documentan
			
			####Documentan procesos planificados
			try: 
				request.POST['planificacionplan']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
				puntoaspecto = 'planificacionplan'
				str_deficiencia = 'Se incumplen los planes de trabajo del mes' 
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			### end documentan
			
			#end planificacion
			
			#CEIS
			
			
			#Utiliza el sistema CEIS para el reporte de las roturas
			
			try: 
				request.POST['ceis1']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
				puntoaspecto = 'ceis1'
				str_deficiencia = 'No se utiliza el sistema CEIS para el reporte de las roturas'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#end Utiliza el sistema CEIS para el reporte de las roturas
			
			#Existe PC sin sello o rotos 
			
			try: 
				request.POST['ceis4']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
				puntoaspecto = 'ceis4'
				str_deficiencia = 'Existen equipos con sellos rotos o sin ellos '
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#end Existe PC sin sello o rotos 
			
			#Se cumple con lo establecido en el Procedimiento para la reparacion y mantenimiento de equipos informaticos. 
			
			try: 
				request.POST['ceis5']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
				puntoaspecto = 'ceis5'
				str_deficiencia = 'No cumplen con lo establecido en el Procedimiento para reparar y dar mantenimiento de equipamiento.  '
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#end Se cumple con lo establecido en el Procedimiento para la reparacion y mantenimiento de equipos informaticos. 
			
			#Coinciden los datos del CEIS con el estado real del equipamiento instalado, la facturación de reparaciones realizadas por Copextel y los componentes entregados a su destino final.
			
			try: 
				request.POST['ceis6']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
				puntoaspecto = 'ceis6'
				str_deficiencia = 'No coinciden los datos del CEIS con el estado real del equipamiento instalado, facturaciones de reparaciones realizadas por Copextel y los componentes entregados a su destino final.'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#end Coinciden los datos del CEIS con el estado real del equipamiento instalado, la facturación de reparaciones realizadas por Copextel y los componentes entregados a su destino final. 
			
			#Estado de completamiento del CEIS: 
			
			try: 
				request.POST['ceis7']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
				puntoaspecto = 'ceis7'
				str_deficiencia = 'El Control de Equipamiento Informático en Salud (CEIS) se encuentra incompleto'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#end Estado de completamiento del CEIS: 
			
			#Estado de la Actualización del CEIS: 
			
			try: 
				request.POST['ceis8']
			except:
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
				puntoaspecto = 'ceis8'
				str_deficiencia = 'El Control de Equipamiento Informático en Salud (CEIS) se encuentra desactualizado'
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#end Estado de la Actualización del CEIS: 
			
			#end ceis
			form_deficiencias = Formulario_Deficiencia()

			return render_to_response('deficiencias/deficiencias.html',{'tipo':tipo,
			'entity':visita,
			'form_deficiencias':form_deficiencias} , context_instance=RequestContext(request))
			
	elif request.POST['hidden'] == "editar":
		deficiencia=Deficiencia.objects.get(id=request.POST['def'])
		deficiencia.deficiencia = request.POST['deficiencia']
		deficiencia.save()

		return render_to_response('deficiencias/deficiencias.html',{'tipo':deficiencia.visita.tipo,
		'entity':deficiencia.visita,
		} , context_instance=RequestContext(request))
		
	elif request.POST['hidden'] == "eliminar":
		deficiencia=Deficiencia.objects.get(id=request.POST['elim'])
		tipo = deficiencia.visita.tipo
		visita = deficiencia.visita
		deficiencia.delete()

		return render_to_response('deficiencias/deficiencias.html',{'tipo':tipo,
		'entity':visita,
		} , context_instance=RequestContext(request))
	else:
		id_visita = request.POST['hidden']
		unidad_visitada = Visita.objects.get(id = id_visita)
		detectado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
		form_deficiencias = Formulario_Deficiencia(request.POST)
		if form_deficiencias.is_valid():
			form = form_deficiencias.save(commit=False)
			form.activo=True
			form.visita = unidad_visitada
			form.estado = detectado
			form.save()
			acciones='La deficiencia '+ str(form.deficiencia) + " fue agregada a la unidad "
			return render_to_response('deficiencias/deficiencias.html',{'tipo':unidad_visitada.tipo,
			'entity':unidad_visitada,
			'form_deficiencias':form_deficiencias} , context_instance=RequestContext(request))	
			
		else:
			form_deficiencias = Formulario_Deficiencia()
		return render_to_response('deficiencias/deficiencias.html',{'form_deficiencias':form_deficiencias} , context_instance=RequestContext(request))


def editar_guia_inspeccion(request):
	unidad_provincial = Unidad.objects.get(id = request.session['unidad'])
	id_editar = request.GET.get('id_editar')
	
	visita_editada = Visita.objects.get(id = id_editar)
	cambiardeficiencias = Deficiencia.objects.filter(visita = visita_editada)
	
	if unidad_provincial.tipo.tipo == 'Direcciones Provinciales de Salud':
		tipo = Nom_Tipo_Visita.objects.get(tipo = 'Integral Provincial')
	else:
		tipo = Nom_Tipo_Visita.objects.get(tipo = 'Integral Municipal')

	id_unidad= visita_editada.unidad.id
	unidad= Unidad.objects.get(id=id_unidad)
	
	permiso=comprobar_perfil(request,unidad.id)
	if permiso == 2:
		return HttpResponseRedirect('/') 
	anno = int(datetime.now().strftime("%Y"))
	anno_anterior=anno-1
	mes = int(datetime.now().strftime("%m"))
	dia = int(datetime.now().strftime("%d"))
	form_participantes=Formulario_Participante()
	#aki cojo la ultima visita a la unidad
	
	
	
	
	
	#end ultima unidad
	
	#aki las deficiencias de esa visita
	deficiencias = Deficiencia.objects.filter(visita__unidad = unidad, estado__estado = 'Detectado')
	fechaf=datetime(anno,mes,dia)
	deficiencias_resueltas= Deficiencia.objects.filter(visita__unidad=id_unidad, estado__estado='Erradicada', fechafin=fechaf)
	
	
	
	carpetadoc = []
	carpetacon = []
	carpetaweb = []
	aspectos = []
	
	for entity in deficiencias:
		if entity.puntoaspecto:
			if entity.puntoaspecto[0:10]=='carpetadoc':
				carpetadoc.append(int(entity.puntoaspecto[10:]))
			elif entity.puntoaspecto[0:10]=='carpetacon':
				carpetacon.append(int(entity.puntoaspecto[10:]))
			elif entity.puntoaspecto[0:10]=='carpetaweb':
				carpetaweb.append(int(entity.puntoaspecto[10:]))
			else:
				aspectos.append(entity.puntoaspecto)
				
	#end deficiencias
	
	#aki los participantes de la provincia
	trabajadoress = Trabajador.objects.annotate(have=Count('perfil__trabajador'))
	dps= Unidad.objects.filter(id=request.session['unidad'])
	fecha = datetime.now()
	participantes = []
	for trabajador in trabajadoress:
		for dpsprov in dps:
			if trabajador.plaza_ocupa.departamento.unidad==dpsprov and trabajador.have == 1:
				participantes.append(trabajador)
		
	#end participantes de la provincia
	
	#aki los usuarios de la unidad
	
	unidad_visitada= Unidad.objects.filter(id=id_unidad)
	
	usuarios = []
	for trabajador in trabajadoress:
		for unidad_visitadaa in unidad_visitada:
			if trabajador.plaza_ocupa.departamento.unidad==unidad_visitadaa and trabajador.have == 1:
				usuarios.append(trabajador)
	
	#end usuarios de la unidad
	
	
	
	#AKi TAREAS DE LOS USUARIOS
	tareas = []
	contador = 0
	reuniones_fechas = []
	for usuario in usuarios:
		tarea=Tarea.objects.filter(responsable = usuario.id, fini__gte = datetime(anno, 1, 1),categoria__categoria = "Reuniones")
		contador = contador + tarea.count()
		tareas.append(tarea)
		for entity in tarea:
			reuniones_fechas.append(entity.fini)
	#END TAREAS DE LOS USUARIOS
	
	#Aki cuento las reuniones
	
	
		
	#end reuniones
	
	#Visitas del usuario
	visitas_usuario = []
	for usuario in usuarios:
		visitas_usuario.append(Visita.objects.filter(participantes = usuario.id, fecha = datetime(anno, 1, 1)))
	
	#END Visitas
	
	#Aki cuento las visitas
	contador_visitas = 0
	visitas_fechas = []
	for entity in visitas_usuario:
		for entity1 in entity:
			if entity1.tipo.tipo == "Integral Municipal":
				contador_visitas = contador_visitas + 1
				visitas_fechas.append(entity1.fecha)
		
	#end visitas
	
	#print tareas
	###############################################
	######AKI COMIENZO EN LA CARPETA DE TRABAJO####
	###############################################
	#documentos oficiales solicitados
	document = Ficheros.objects.filter(unidad=id_unidad)
	#END documentos oficiales
	#documentos oficiales subidos por el usuario
	fichero = Documentos.objects.filter(documento=document, unidad =unidad)
	files = []
	for file in fichero: 
		files.append(file.documento)
	#end ficheros oficiales
	
	#objeto conectividad
	conectividad1 = Conectividad.objects.filter(unidad=unidad)
	conectividadd = conectividad1
	if conectividad1:
		conectividadd = conectividad1[0]

	#Tomando objeto enlace
	enlace = Enlaces.objects.filter(conectividad=conectividadd)
	#Tomando Paginas web
	webs = P_web.objects.filter(conectividad=conectividadd)
	print aspectos
	return render_to_response('visita/editar_guia_inspeccion.html',
	{'unidad':unidad,
	'participantes':participantes,
	'fecha':fecha,
	'anno':anno,
	'anno_anterior':anno_anterior,
	'mes': mes,
	'carpetadoc':carpetadoc,
	'carpetacon':carpetacon,
	'carpetaweb':carpetaweb,
	'aspectos':aspectos,
	'deficiencias':deficiencias,
	'deficiencias_resueltas':deficiencias_resueltas,
	'document':document,
	'fichero':fichero,
	'files':files,
	'enlace':enlace,
	'contador_visitas':contador_visitas,
	'visitas_fechas':visitas_fechas,
	'webs':webs,
	'usuarios':usuarios,
	'contador':contador,
	'reuniones_fechas':reuniones_fechas,
	'tareas':tareas,
	'tipo':tipo,
	'id_unidad':id_unidad,
	'visita_editada':visita_editada,
	'form_participantes':form_participantes
	}
	, context_instance=RequestContext(request))
	
	
def editar_deficiencia(request):
	
	if request.POST['hidden'] == "inspeccion":
		dia = int(request.POST['dia'])
		mes = int(request.POST['mes'])
		anno = int(request.POST['anno'])
		fecha1=datetime(anno,mes,dia,00,00,00)
		fecha2= datetime(anno,mes,dia,23,59,59)
		unidad1 = Unidad.objects.get(id = request.POST['unidad'])
		permiso=comprobar_perfil(request,unidad1.id)
		if permiso == 2:
			return HttpResponseRedirect('/') 
		#Aki estamos creando una visita
					
		
		tipo = Nom_Tipo_Visita.objects.get(tipo = request.POST['tipo'])

		form_participantes = Formulario_Participante(request.POST)
		visitado = Trabajador.objects.get(id = request.POST['visitado'])

		participantes = form_participantes['participantes'].value()

		fecha = date(anno, mes, dia)
		activo = False
			
		visita =Visita.objects.get(id = request.POST['editar'])
		visita.tipo = tipo
		visita.unidad = unidad1
		visita.fecha = fecha
		visita.visitado = visitado.nombre
		visita.activo = activo
			
		for entity in participantes:
			visita.participantes.add(Trabajador.objects.get(id=entity))
		visita.save()
			#end visita
			
			#Aki Creo las deficiencias con docuemntos
		documentos_faltantes = []
		document = Ficheros.objects.filter(unidad=request.POST['unidad'])
		
		conect = Enlaces.objects.filter(conectividad__unidad=request.POST['unidad'])
		
		web = P_web.objects.filter(conectividad__unidad=request.POST['unidad'])
		
		for i in document:
			carpetadoc = 'carpetadoc'+str(i.id)
			try: 
				request.POST[carpetadoc]
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = carpetadoc, estado = estado)
				deficiencia_borrar.delete()
			except: 
				documento = Ficheros.objects.get(id = i.id)
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Carpeta de Trabajo')
				puntoaspecto = 'carpetadoc'+str(i.id)
				str_deficiencia = string_concat('Falta el documento ', documento.nombre)
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
			#
			#aki deficiencias con conectividad
		for j in conect:
			carpetacon = 'carpetacon'+str(j.id)
			
			try: 
				request.POST[carpetacon]
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = carpetacon, estado = estado)
				deficiencia_borrar.delete()
				
			except: 
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Carpeta de Trabajo')
				puntoaspecto = 'carpetacon'+str(j.id)
				enlace_true = Enlaces.objects.filter(conectividad__unidad = request.POST['unidad'])
				if enlace_true:
					str_deficiencia = 'Tiene mal los datos de su enlace ' 
				else:
					str_deficiencia = 'No tiene enlace insertado '
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
			
		#end conectividad
		for h in web:
			carpetaweb = 'carpetaweb'+str(h.id)
			try: 
				request.POST[carpetaweb]
				
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = carpetaweb, estado = estado)
				deficiencia_borrar.delete()
					
			except: 
					
				estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
				aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Carpeta de Trabajo')
				puntoaspecto = 'carpetaweb'+str(h.id)
				enlace_true = P_web.objects.filter(conectividad__unidad = request.POST['unidad'])
				if enlace_true:
					str_deficiencia = 'Su pagina web es incorrecta ' 
				else:
					str_deficiencia = 'No tiene pagina web '
				deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
				if len(deficiencia_vieja) == 0:			
					deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
					deficiencia.save()
		#aki la planificacion
		####Reuniones de departamento
		try: 
			request.POST['planificacion1']
			planificacion1 = 'planificacion1'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = planificacion1, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
			puntoaspecto = 'planificacion1'
			str_deficiencia = 'No realiza reuniones de departamento/municipio'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		### end reuniones
		
		####Actas de Acuerdos
		try: 
			request.POST['planificacion2']
			planificacion2 = 'planificacion2'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = planificacion2, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
			puntoaspecto = 'planificacion2'
			str_deficiencia = 'No se realizan las actas de acuerdos'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:							
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		### end actas
		
		####Seguimiento a acuerdos
		try: 
			request.POST['planificacion3']
			planificacion3 = 'planificacion3'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = planificacion3, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
			puntoaspecto = 'planificacion3'
			str_deficiencia = 'No le da seguimiento a los acuerdos tomados'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		### end seguimientos
		
		####Vistitas a unidades de subordinacion
		try: 
			request.POST['planificacion4']
			planificacion4 = 'planificacion4'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = planificacion4, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
			puntoaspecto = 'planificacion4'
			str_deficiencia = 'No realiza visitas a unidaddes de subordinacion' 
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		### end seguimientos
		
		####Cumplimiento del plan de trabajo mensual
		try: 
			request.POST['planificacion5']
			planificacion5 = 'planificacion5'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = planificacion5, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
			puntoaspecto = 'planificacion5'
			str_deficiencia = 'No se evalua el cumplimiento de los planes de trabajo mensual'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		### end plan
		
		####Documentan procesos planificados
		try: 
			request.POST['planificacion6']
			planificacion6 = 'planificacion6'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = planificacion6, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
			puntoaspecto = 'planificacion6'
			str_deficiencia = 'No se cumplen y documentan los procesos planificados'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		### end documentan
		
		####Documentan procesos planificados
		try: 
			request.POST['planificacionplan']
			planificacionplan = 'planificacionplan'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = planificacionplan, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'Planificación')
			puntoaspecto = 'planificacionplan'
			str_deficiencia = 'Se incumplen los planes de trabajo del mes' 
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		### end documentan
		
		#end planificacion
		
		#CEIS
		
		
		#Utiliza el sistema CEIS para el reporte de las roturas
		
		try: 
			request.POST['ceis1']
			ceis1 = 'ceis1'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = ceis1, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
			puntoaspecto = 'ceis1'
			str_deficiencia = 'No se utiliza el sistema CEIS para el reporte de las roturas'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		
		#end Utiliza el sistema CEIS para el reporte de las roturas
		
		#Existe PC sin sello o rotos 
		
		try: 
			request.POST['ceis4']
			ceis4 = 'ceis4'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = ceis4, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
			puntoaspecto = 'ceis4'
			str_deficiencia = 'Existen equipos con sellos rotos o sin ellos '
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		
		#end Existe PC sin sello o rotos 
		
		#Se cumple con lo establecido en el Procedimiento para la reparacion y mantenimiento de equipos informaticos. 
		
		try: 
			request.POST['ceis5']
			ceis5 = 'ceis5'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = ceis5, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
			puntoaspecto = 'ceis5'
			str_deficiencia = 'No cumplen con lo establecido en el Procedimiento para reparar y dar mantenimiento de equipamiento.  '
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		
		#end Se cumple con lo establecido en el Procedimiento para la reparacion y mantenimiento de equipos informaticos. 
		
		#Coinciden los datos del CEIS con el estado real del equipamiento instalado, la facturación de reparaciones realizadas por Copextel y los componentes entregados a su destino final.
		
		try: 
			request.POST['ceis6']
			ceis6 = 'ceis6'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = ceis6, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
			puntoaspecto = 'ceis6'
			str_deficiencia = 'No coinciden los datos del CEIS con el estado real del equipamiento instalado, facturaciones de reparaciones realizadas por Copextel y los componentes entregados a su destino final.'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		
		#end Coinciden los datos del CEIS con el estado real del equipamiento instalado, la facturación de reparaciones realizadas por Copextel y los componentes entregados a su destino final. 
		
		#Estado de completamiento del CEIS: 
		
		try: 
			request.POST['ceis7']
			ceis7 = 'ceis7'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = ceis7, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
			puntoaspecto = 'ceis7'
			str_deficiencia = 'El Control de Equipamiento Informático en Salud (CEIS) se encuentra incompleto'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		
		#end Estado de completamiento del CEIS: 
		
		#Estado de la Actualización del CEIS: 
		
		try: 
			request.POST['ceis8']
			ceis8 = 'ceis8'
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			deficiencia_borrar = Deficiencia.objects.filter(puntoaspecto = ceis8, estado = estado)
			deficiencia_borrar.delete()
		except:
			
			estado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
			aspecto = Nom_Aspecto_Deficiencia.objects.get(aspecto = 'CEIS')
			puntoaspecto = 'ceis8'
			str_deficiencia = 'El Control de Equipamiento Informático en Salud (CEIS) se encuentra desactualizado'
			deficiencia_vieja = Deficiencia.objects.filter(puntoaspecto = puntoaspecto, estado = estado, visita__unidad = unidad1)
			if len(deficiencia_vieja) == 0:			
				deficiencia = Deficiencia.objects.create(visita = visita, deficiencia = str_deficiencia, estado = estado, aspecto = aspecto, observaciones = '', puntoaspecto =  puntoaspecto, activo = True)
				deficiencia.save()
		
		#end Estado de la Actualización del CEIS: 
		
		#end ceis
		form_deficiencias = Formulario_Deficiencia()
		return render_to_response('deficiencias/editar_deficiencias.html',{'tipo':tipo,
		'entity':visita,
		'form_deficiencias':form_deficiencias} , context_instance=RequestContext(request))
	elif request.POST['hidden'] == "editar":
		
			deficiencia=Deficiencia.objects.get(id=request.POST['def'])
			deficiencia.deficiencia = request.POST['deficiencia']
			deficiencia.save()

			return render_to_response('deficiencias/editar_deficiencias.html',{'tipo':deficiencia.visita.tipo,
			'entity':deficiencia.visita,
			} , context_instance=RequestContext(request))
	
	elif request.POST['hidden'] == "eliminar":
		deficiencia=Deficiencia.objects.get(id=request.POST['elim'])
		tipo = deficiencia.visita.tipo
		visita = deficiencia.visita
		deficiencia.delete()

		return render_to_response('deficiencias/deficiencias.html',{'tipo':tipo,
		'entity':visita,
		} , context_instance=RequestContext(request))
	else:
		id_visita = request.POST['hidden']
		unidad_visitada = Visita.objects.get(id = id_visita)
		detectado = Nom_Estado_Deficiencia.objects.get(estado = 'Detectado')
		form_deficiencias = Formulario_Deficiencia(request.POST)
		if form_deficiencias.is_valid():
			form = form_deficiencias.save(commit=False)
			form.activo=True
			form.visita = unidad_visitada
			form.estado = detectado
			form.save()
			acciones='La deficiencia '+ str(form.deficiencia) + " fue agregada a la unidad "
			return render_to_response('deficiencias/editar_deficiencias.html',{'tipo':unidad_visitada.tipo,
			'entity':unidad_visitada,
			'form_deficiencias':form_deficiencias} , context_instance=RequestContext(request))	
			
		else:
			form_deficiencias = Formulario_Deficiencia()
		return render_to_response('deficiencias/editar_deficiencias.html',{'form_deficiencias':form_deficiencias} , context_instance=RequestContext(request))		
		







@login_required(login_url='/ingresar')
def info_visita(request):
	id_visita=request.GET.get('id')
	entity= Visita.objects.get(id=id_visita)
	permiso=comprobar_perfil(request,entity.unidad.id)
	if permiso ==2 and entity.unidad.id!=request.session['unidad']:
		return HttpResponseRedirect('/')
	unidad=entity.participantes.all()[0].plaza_ocupa.departamento.unidad
	return render_to_response('visita/info_visita.html',{'entity':entity,'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def deficiencias_unidad(request):
	id_unidad=request.GET.get('id')
	unidad= Unidad.objects.get(id=id_unidad)
	deficiencias= Deficiencia.objects.filter(visita__unidad=id_unidad, estado__estado='Detectado')
	permiso=comprobar_perfil(request,unidad.id)
	if permiso ==2 or unidad.id == request.session['unidad']:
		return HttpResponseRedirect('/')
	return render_to_response('deficiencias/deficiencias_unidad.html',{'deficiencias':deficiencias,'unidad':unidad} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def ver_deficiencia(request):
	id_deficiencia=request.GET.get('id')
	deficiencia= Deficiencia.objects.get(id=id_deficiencia)
	permiso=comprobar_perfil(request,deficiencia.visita.unidad.id)
	if permiso ==2 and deficiencia.visita.unidad.id!=request.session['unidad']:
		return HttpResponseRedirect('/')
	return render_to_response('deficiencias/ver_deficiencia.html',{'deficiencia':deficiencia} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def visto_bueno(request):
	id_visita=request.GET.get('id')
	entity= Visita.objects.get(id=id_visita)
	if entity.unidad.id!=request.session['unidad']:
		return HttpResponseRedirect('/')
	entity.activo=True
	entity.save()
	request.session['inspeccion']={}
	request.session['fechainsp']=[]
	inspecciones= Visita.objects.filter(unidad=entity.unidad.id,activo=False)
	for insp in inspecciones:
		request.session['inspeccion'][str(insp.id)]=('Visita '+insp.tipo.tipo+' sin visto bueno')
		request.session['fechainsp'].append(insp.fecha.strftime('%d-%m-%Y'))
	return HttpResponseRedirect('info_visita?id='+id_visita)

@login_required(login_url='/ingresar')
def erradicar_deficiencia(request):
	id_deficiencia=request.GET.get('id')
	deficiencia= Deficiencia.objects.get(id=id_deficiencia)
	permiso=comprobar_perfil(request,deficiencia.visita.unidad.id)
	if permiso ==2 or deficiencia.visita.unidad.id == request.session['unidad']:
		return HttpResponseRedirect('/')
	estado= Nom_Estado_Deficiencia.objects.get(estado='Erradicada')
	deficiencia.estado=estado
	deficiencia.fechafin=datetime(int(datetime.now().strftime('%Y')),int(datetime.now().strftime('%m')),int(datetime.now().strftime('%d')))
	deficiencia.save()
	return HttpResponseRedirect('deficiencias_unidad?id='+str(deficiencia.visita.unidad.id))
	
# exportando visitas
@login_required(login_url='/ingresar')
class IndexView(ListView):
	template_name = "index.html"
	model = Tarea
	context_object_name = "t"
 
def exportar_inspeccion(request):

	id_unidad=request.GET.get('id')
	id_visita=request.GET.get('v')
	visita= Visita.objects.get(id=id_visita)
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 and id_unidad!=request.session['unidad']:
		return HttpResponseRedirect('/')
	participan= visita.participantes.all()
	visitado = visita.visitado
	fechaf=datetime(int(visita.fecha.strftime('%Y')),int(visita.fecha.strftime('%m')),int(visita.fecha.strftime('%d')))
	
	#~ deficiencias detectadas ()
	detectadashoy= Deficiencia.objects.filter(visita__unidad=id_unidad, estado__estado='Detectado', visita=visita)
	detectadas= Deficiencia.objects.filter(Q(visita__unidad=id_unidad, estado__estado='Detectado',visita__fecha__lte=fechaf)|Q(visita__unidad=id_unidad, estado__estado='Erradicada',visita__fecha__lte=fechaf,fechafin__gte=fechaf)).exclude(visita=visita)
	erradicadas= Deficiencia.objects.filter(visita__unidad=id_unidad, estado__estado='Erradicada', fechafin=fechaf).count()

	contar_detectadashoy = detectadashoy.count()
	
	deficiencias= detectadas.count()
	total=erradicadas+deficiencias

	response = HttpResponse(content_type='application/pdf')
	pdf_name = "Inspección.pdf"  

	buff = BytesIO()

	doc = SimpleDocTemplate(buff,
							pagesize=portrait(letter),
							rightMargin=30,
							leftMargin=30,
							topMargin=15,
							bottomMargin=15,
							)

	inspeccion=[]
	styles = getSampleStyleSheet()
	styleSheet = getSampleStyleSheet()

# Personal que inspecciona 
	inspeccionan = '<para align=left><font size=10><b> Personal que Inspecciona : </b><br></br>'
	u=0
	for participante in participan:
		u=u+1
		inspeccionan = inspeccionan+participante.nombre+ '<br></br>'
	inspeccionan = inspeccionan+'</font></para>'
# /Personal que inspecciona 


	carpeta =False
	ceis = False
	planificacion = False
	otras = False

	carpeta1 =False
	ceis1 = False
	planificacion1 = False
	otras1 = False


# deficiencias de la visita actual
	if detectadashoy.filter(aspecto__aspecto='Carpeta de Trabajo').count()>0:
		contar_carpeta = detectadashoy.filter(aspecto__aspecto='Carpeta de Trabajo').count()
		carpeta = '<para align=left><font size=10><b> Carpeta de Trabajo: ('+str(contar_carpeta) +')</b><br></br>'
		u=0
		for detectada in detectadashoy.filter(aspecto__aspecto='Carpeta de Trabajo'):
			u=u+1
			carpeta = carpeta+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		carpeta = carpeta+ '<br></br></font></para>'

	if detectadashoy.filter(aspecto__aspecto='Planificación').count()>0:
		contar_panificacion = detectadashoy.filter(aspecto__aspecto='Planificación').count()
		planificacion = '<para align=left><font size=10><b>Planificacion: </b>('+str(contar_panificacion) +')<br></br>'
		u=0
		for detectada in detectadashoy.filter(aspecto__aspecto='Planificación'):
			u=u+1
			planificacion = planificacion+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		planificacion = planificacion+ '<br></br></font></para>'
	
	if detectadashoy.filter(aspecto__aspecto='CEIS').count()>0:
		contar_ceis = detectadashoy.filter(aspecto__aspecto='CEIS').count()
		ceis = '<para align=left><font size=10><b>CEIS: </b>('+str(contar_ceis)+')<br></br>'
		u=0
		for detectada in detectadashoy.filter(aspecto__aspecto='CEIS'):
			u=u+1
			ceis = ceis+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		ceis = ceis+ '<br></br></font></para>'
	
	if detectadashoy.filter(aspecto__aspecto='Otras').count()>0:
		contar_otras = detectadashoy.filter(aspecto__aspecto='Otras').count()
		otras = '<para align=left><font size=10><b>Otras: </b>('+str(contar_otras) +')<br></br>'
		u=0
		for detectada in detectadashoy.filter(aspecto__aspecto='Otras'):
			u=u+1
			otras = otras+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		otras = otras+ '<br></br></font></para>'
 

# deficiencias de visitas anteriores
	if detectadas.filter(aspecto__aspecto='Carpeta de Trabajo').count()>0:
		contar_carpeta1 = detectadas.filter(aspecto__aspecto='Carpeta de Trabajo').count()
		carpeta1 = '<para align=left><font size=10><b> Carpeta de Trabajo: </b>('+str(contar_carpeta1) +')<br></br>'
		u=0
		for detectada in detectadas.filter(aspecto__aspecto='Carpeta de Trabajo'):
			u=u+1
			carpeta1 = carpeta1+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		carpeta1 = carpeta1+ '<br></br></font></para>'

	if detectadas.filter(aspecto__aspecto='Planificación').count()>0:
		contar_panificacion1 = detectadas.filter(aspecto__aspecto='Planificación').count()
		planificacion1 = '<para align=left><font size=10><b>Planificacion: </b>('+str(contar_panificacion1) +')<br></br>'
		u=0
		for detectada in detectadas.filter(aspecto__aspecto='Planificación'):
			u=u+1
			planificacion1 = planificacion1+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		planificacion1 = planificacion1+ '<br></br></font></para>'
	
	if detectadas.filter(aspecto__aspecto='CEIS').count()>0:
		contar_ceis1 = detectadas.filter(aspecto__aspecto='CEIS').count()
		ceis1 = '<para align=left><font size=10><b>CEIS: </b>('+str(contar_ceis1) +')<br></br>'
		u=0
		for detectada in detectadas.filter(aspecto__aspecto='CEIS'):
			u=u+1
			ceis1 = ceis1+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		ceis1 = ceis1+ '<br></br></font></para>'
	
	if detectadas.filter(aspecto__aspecto='Otras').count()>0:
		contar_otras1 = detectadas.filter(aspecto__aspecto='Otras').count()
		otras1 = '<para align=left><font size=10><b>Otras: </b>('+str(contar_otras1) +')<br></br>'
		u=0
		for detectada in detectadas.filter(aspecto__aspecto='Otras'):
			u=u+1
			otras1 = otras1+' '+str(u)+'- '+ detectada.deficiencia+ '<br></br>'
		otras1 = otras1+ '<br></br></font></para>'



#~ Portada
	I = Image("/var/www/SII/Proyecto/static/esculapio.png")
	I.drawHeight = 0.80*inch*I.drawHeight / I.drawWidth
	I.drawWidth = 0.80*inch

	mes = int(visita.fecha.strftime('%m'))
	if mes == 1:
		descmes='Enero'
	if mes == 2:
		descmes='Febrero'
	if mes == 3:
		descmes='Marzo'
	if mes == 4:
		descmes='Abril'
	if mes == 5:
		descmes='Mayo'
	if mes == 6:
		descmes='Junio'
	if mes == 7:
		descmes='Juli'
	if mes == 8:
		descmes='Agosto'
	if mes == 9:
		descmes='Septiembre'
	if mes == 10:
		descmes='Octubre'
	if mes == 11:
		descmes='Noviembre'
	if mes == 12:
		descmes='Diciembre'

	Ti = Paragraph(string_concat('''<para align=center><font size=16 ><b>Informe de la Inspección ''',visita.tipo.tipo,'''</font></b><br></br><br></br><font size=12 >''',visita.fecha.strftime('%d'),' de ',descmes, ' del ',visita.fecha.strftime('%Y'),'''</font></para>'''),styleSheet["BodyText"])
	Un = Paragraph('''<para align=left><font size=12 ><b>Unidad: </b><font size=10>'''+visita.unidad.nombre+'''</font></font></para>''',styleSheet["BodyText"])

	visit = Paragraph('''<para align=left><font size=10 ><b>Visitado: </b><br></br>'''+visita.visitado+'''<br></br><br></br></font></para>''',styleSheet["BodyText"])

	Mu = Paragraph('''<para align=left><font size=12 ><b>Municipio: </b><font size=10>'''+visita.unidad.municipio.municipio+'''<br></br><br></br><br></br></font></font></para>''',styleSheet["BodyText"])
	Dva = Paragraph('''<para align=left><b>Deficiencias anteriores: </b><br></br>'''+'  Aspectos señalados:('+str(total)+') Resueltos: ('+str(erradicadas)+')'+'''<br></br><br></br></font></para>''',styleSheet["BodyText"])
	TotalHoy = Paragraph('''<para align=left><font size=11> Aspectos señalados: ('''+str(contar_detectadashoy)+''')</font></para>''',styleSheet["BodyText"])
	Dhoy = Paragraph('''<para align=left><b>Deficiencias actuales: </b></para>''',styleSheet["BodyText"])
	Pr = Paragraph('''<para align=left><font size=12 ><b>Principles tareas: </b></font></para>''',styleSheet["BodyText"])
	

	img= [
		['','',''],
		['',[I],'']
		]


	inspeccion.append(Ti)
	IMG = Table(img)
	inspeccion.append(IMG)
	inspeccion.append(Un)
	inspeccion.append(Mu)
	inspeccion.append(Paragraph(inspeccionan,styleSheet["BodyText"]))
	inspeccion.append(visit)


	if detectadas:
		inspeccion.append(Dva)

		if carpeta1:
			inspeccion.append(Paragraph(carpeta1,styleSheet["BodyText"]))
		if planificacion1:
			inspeccion.append(Paragraph(planificacion1,styleSheet["BodyText"]))
		if ceis1:
			inspeccion.append(Paragraph(ceis1,styleSheet["BodyText"]))
		if otras1:
			inspeccion.append(Paragraph(otras1,styleSheet["BodyText"]))


	if detectadashoy:
		inspeccion.append(Dhoy)
		inspeccion.append(TotalHoy)

		if carpeta:
			inspeccion.append(Paragraph(carpeta,styleSheet["BodyText"]))
		if planificacion:
			inspeccion.append(Paragraph(planificacion,styleSheet["BodyText"]))
		if ceis:
			inspeccion.append(Paragraph(ceis,styleSheet["BodyText"]))
		if otras:
			inspeccion.append(Paragraph(otras,styleSheet["BodyText"]))
		
	doc.build(inspeccion)
	response.write(buff.getvalue())
	buff.close()
	return response

# /exportando visitas

