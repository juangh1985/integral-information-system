from django.forms import *
from django import forms
from inspeccion.models import *



class Formulario_Deficiencia(ModelForm):
	class Meta:
		model = Deficiencia
		exclude=('tarea', 'fechafin', 'activo', 'puntoaspecto', 'visita', 'estado')
		widgets = {
			
			'Deficiencia': Textarea(attrs={"class" :'form-control','placeholder': 'Deficiencia','required':'true'}),
			'Aspecto': Select(attrs={'class' :'select2','placeholder': 'Aspecto','required':'true'}),
			'Observaciones': Textarea(attrs={"class":"form-control", "rows":"6", "cols":"30", "maxlength":"140", 'placeholder': 'Observaciones'}),
			
			}


class Formulario_Participante(ModelForm):
	class Meta:
		model = Visita
		exclude=('activo','tipo','unidad','fecha','visitado',)
		widgets = {
			'participantes': SelectMultiple(attrs={'multiple':'', 'class' :'select2 select2-multiple','placeholder': 'Participantes'}),
			}
