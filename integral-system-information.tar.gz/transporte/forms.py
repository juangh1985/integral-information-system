from django.forms import *
from django import forms
from transporte.models import *


class formulario_parque(ModelForm):
	class Meta:
		model = parque
		exclude=('orden','ficav','operativa','circulacion','unidad',)

		widgets = {
'orden': TextInput(attrs={'class' :'form-control','placeholder': 'Orden'}),
'unidad': TextInput(attrs={'class' :'form-control','placeholder': 'Unidad'}),
'matricula': TextInput(attrs={'class' :'form-control','placeholder': 'Matricula'}),
'tipo': Select(attrs={"class" :"select2",'placeholder': 'Tipo'}),
'marca': Select(attrs={"class" :"select2",'placeholder': 'Tipo'}),
'modelo': TextInput(attrs={'class' :'form-control','placeholder': 'Modelo'}),
'serie': TextInput(attrs={'class' :'form-control','placeholder': 'Serie'}),
'motor': TextInput(attrs={'class' :'form-control','placeholder': 'Motor'}),
'estadotecnico': Select(attrs={"class" :"select2",'placeholder': 'Tipo'}),
'estadooperativo': Select(attrs={"class" :"select2",'placeholder': 'Tipo'}),
'combustible': Select(attrs={"class" :"select2",'placeholder': 'Tipo'}),
'funcion': Select(attrs={"class" :"select2",'placeholder': 'Funcion'}),
'neumatico': Select(attrs={"class" :"select2",'placeholder': 'Tipo'}),
'bateria': Select(attrs={"class" :"select2",'placeholder': 'Tipo'}),
'demanda': SelectMultiple(attrs={'multiple':'', 'class' :'select2 select2-multiple','placeholder': 'Demanda'}),
'comentario': Textarea(attrs={'class' :'form-control','placeholder': 'Comentario'}),
}
