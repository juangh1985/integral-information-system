from django.forms import *
from django import forms
from rrhh.models import *


class Formulario_Trabajador(ModelForm):
	class Meta:
		model = Trabajador
		exclude=('estado',)
		widgets = {
			'nombre': TextInput(attrs={'class' :'form-control','placeholder': 'Nombre','required':'true'}),
			'carne': TextInput(attrs={'class' :'form-control','placeholder': 'Carnet','required':'true'}),
			'correo': TextInput(attrs={'class' :'form-control','placeholder': 'Correo','required':'true'}),
			'direccion': TextInput(attrs={'class' :'form-control','placeholder': 'Direccion','required':'true'}),
			'municipio': Select(attrs={'class' :'select2','placeholder': 'Municipio','required':'true'}),
			'titulo': Select(attrs={'class' :'select2','placeholder': 'Titulo','required':'true'}),
			'graduado': TextInput(attrs={'class' :'form-control','placeholder': 'Graduado de','required':'true'}),
			'habilidad': SelectMultiple(attrs={'multiple':'', 'class' :'select2 select2-multiple','placeholder': 'Habilidades'}),
			'telefono': TextInput(attrs={'class' :'form-control','placeholder': 'Telefono','required':'true'}),
			'cargo': SelectMultiple(attrs={'multiple':'', 'class' :'select2 select2-multiple','placeholder': 'Cargo'}),
			}


