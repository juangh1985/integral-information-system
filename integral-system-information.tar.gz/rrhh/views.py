#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.shortcuts import render
from datetime import *

# Create your views here.
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from unidad.views import *
from rrhh.models import *
from transporte.models import *
from radio.models import *
from carpeta.models import *
from inspeccion.models import *
from tareas.models import *
from mensajes.models import *
from presupuesto.models import *
#~ from singeniero.models import *

from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest, HttpResponse
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from unidad.forms import Formulario_Departamento, Formulario_Unidad,  Formulario_Plaza_Departamento
from rrhh.forms import  Formulario_Trabajador
from django.db.models import Sum
from django.db.models import Count


from django.views.generic import UpdateView

#~ from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Table, TableStyle,PageBreak
#~ from reportlab.lib.styles import getSampleStyleSheet
#~ from reportlab.lib import colors
#~ from reportlab.lib.pagesizes import letter, inch, landscape, portrait
#~ from reportlab.lib.enums import TA_CENTER
from django.utils.translation import string_concat
from django.views.generic import UpdateView, ListView
from io import BytesIO

def ingresar(request):

	if request.method == 'POST':
		ingreso = AuthenticationForm(request.POST)

		if ingreso.is_valid:
			usuario = request.POST['username1']
			clave = request.POST['password1']
			acceso =authenticate(username=usuario, password=clave)

			if acceso is not None:

				if acceso.is_active:
					login(request, acceso)
					

					id_usuario = User.objects.get(username=usuario)
					perfil = Perfil.objects.get(user_id=id_usuario.id)
					unidad_rad=unidad_radio.objects.filter(unidad=perfil.trabajador.plaza_ocupa.departamento.unidad.id)
					foto=str(perfil.trabajador.imagen)
					if id_usuario.is_staff:
						mensajes_sin_moderar = mensaje.objects.filter(Q(estado=0,destinatario=perfil.trabajador.id)|Q(estado=0,destinatario__isnull=True))
					else:
						mensajes_sin_moderar = mensaje.objects.filter(estado=0,destinatario=perfil.trabajador.id) 
					request.session['mensajes']={}
					for mensaje1 in mensajes_sin_moderar:
						if mensaje_leido.objects.filter(mensaje=mensaje1,trabajador=perfil.trabajador.id).count()==0:
							request.session['mensajes'][str(mensaje1.id)]='<div class="pull-left"><img class="media-object" src="Galeria/'+str(Perfil.objects.get(user_id=mensaje1.remitente).trabajador.imagen)+'" ></div><div class="media-body"><h5 class="media-heading name">'+mensaje1.remitente.username+'</h5><p class="text">' + mensaje1.asunto + '</p><span class="timestamp">'+mensaje1.registro.strftime('%d-%m-%Y')+'</span></div>'

					request.session['inspeccion']={}
					request.session['fechainsp']=[]
					inspecciones= Visita.objects.filter(unidad=perfil.trabajador.plaza_ocupa.departamento.unidad.id,activo=False)
					for insp in inspecciones:
						request.session['inspeccion'][str(insp.id)]='Visita '+insp.tipo.tipo+' sin visto bueno'
						request.session['fechainsp'].append(insp.fecha.strftime('%d-%m-%Y'))


					presupuesto = Presupuesto_Unidad.objects.filter(unidad=perfil.trabajador.plaza_ocupa.departamento.unidad.id)

					if len(presupuesto) > 0:

						request.session['presupuesto']= 'Presupuesto'



					request.session['foto']=foto
					request.session['userid']=id_usuario.id
					request.session['nombre']= perfil.trabajador.nombre
					print len(unidad_rad)
					if len(unidad_rad) >0:
						request.session['radio']='tiene'
					else:
						request.session['radio']='no tiene'
					request.session['unidad']= perfil.trabajador.plaza_ocupa.departamento.unidad.id
					request.session['organizativa']= perfil.trabajador.plaza_ocupa.departamento.nombre.nombre
					request.session['trabajador']= perfil.trabajador.id
					acciones="Ha iniciado sesion"
					registrar_log(request,acciones,1)
					return HttpResponseRedirect('/')
				else:
					error="Su usuario esta bloqueado contacte con el administador"
					return render_to_response('login.html', {'ingreso':ingreso, 'error':error}, context_instance = RequestContext(request))
			else:
				error="El usuario de acceso o la clave que has introducido no son correcta"
				return render_to_response('login.html', {'ingreso':ingreso, 'error':error}, context_instance = RequestContext(request))

	else:
		ingreso = AuthenticationForm()
	return render_to_response('login.html', {'ingreso':ingreso}, context_instance = RequestContext(request))


@login_required(login_url='/ingresar')
def cambiar_clave(request):

	if request.method == 'POST':
		usuario = request.user.username
		usuario1=User.objects.get(username=usuario)
		clave_new = request.POST['password1']
		clave_new1 = request.POST['password2']
		clave_old = request.POST['password']
		if usuario1.check_password(clave_old):
			if len(clave_new) >= 4:
				if clave_new == clave_new1:
					usuario1.set_password(clave_new)
					usuario1.save()
					confirmacion="Clave cambiada de forma satisfactoria"
					error=""
				else:
					confirmacion=""
					error="Las claves deben coincidir"
				return render_to_response('cambiar_clave.html', { 'confirmacion':confirmacion, 'error':error}, context_instance = RequestContext(request))
			else:
				error="La nueva clave tiene que tener mas de 4 caracteres"
				return render_to_response('cambiar_clave.html', {'error':error}, context_instance = RequestContext(request))
		else:
			error="La clave que has introducido no es correcta"
			return render_to_response('cambiar_clave.html', { 'error':error}, context_instance = RequestContext(request))

	return render_to_response('cambiar_clave.html',  context_instance = RequestContext(request))
@login_required(login_url='/ingresar')

def cerrar(request):
	acciones="Ha cerrado sesion"
	registrar_log(request,acciones,5)
	logout(request)
	return HttpResponseRedirect('/')



@login_required(login_url='/ingresar')
def inicial(request):


	## para transporte
	am=parque.objects.filter(unidad=request.session['unidad'], estadotecnico=3).count()
	ar=parque.objects.filter(unidad=request.session['unidad'], estadotecnico=2).count()
	ab=parque.objects.filter(unidad=request.session['unidad'], estadotecnico=1).count()

	et=parque.objects.filter(unidad=request.session['unidad'], estadooperativo=1).count()
	ep=parque.objects.filter(unidad=request.session['unidad'], estadooperativo=2).count()
	eb=parque.objects.filter(unidad=request.session['unidad'], estadooperativo=3).count()

	autos = marca.objects.annotate(parque1=Count('parque__marca')).order_by('marca')
	## para transporte



	## para informatica
	
	mensajes = categoria.objects.annotate(mensa=Count('mensaje__categoria')).order_by('categoria')


	## para informatica
#~ 
	#~ import os
	#~ maq = maquina.objects.all()
	#~ registromaq = registromaquina.objects.all().order_by('-fecha')
#~ 
	#~ registrado = set()
	#~ unicos = []
	#~ for e in registromaq:
		#~ if e.pc not in registrado:
			#~ unicos.append(e)
			#~ registrado.add(e.pc)
#~ 
#~ 
	#~ for e in maq:
		#~ response = os.system("ping -c 1 -W 1 " + e.ip)
		#~ print response
		#~ if response == 0:
			#~ si = registromaquina(pc=e, estado='1')
			#~ si.save()
		#~ else:
			#~ no = registromaquina(pc=e, estado='0')
			#~ no.save()




	id_unidad=request.session['unidad']
	organizativa=request.session['organizativa']
	unidad= Unidad.objects.get(id=id_unidad)

#~ 
#~ 
#~ 
	#~ asceb=ascensor.objects.filter(estado=1).count()
	#~ ascer=ascensor.objects.filter(estado=2).count()
	#~ ascem=ascensor.objects.filter(estado=3).count()
#~ 
	#~ geb=grupo_electrogeno.objects.filter(estado=1).count()
	#~ ger=grupo_electrogeno.objects.filter(estado=2).count()
	#~ gem=grupo_electrogeno.objects.filter(estado=3).count()
#~ 
#~ 
#~ 


	return render_to_response('portada.html',{
	#~ 'unicos':unicos,

#~ 
	#~ 'geb':geb,
	#~ 'ger':ger,
	#~ 'gem':gem,
#~ 
#~ 
	#~ 'asceb':asceb,
	#~ 'ascer':ascer,
	#~ 'ascem':ascem,

	'et':et,
	'ep':ep,
	'eb':eb,
	'am':am,
	'ar':ar,
	'ab':ab,
	'autos':autos,
	'mensajes':mensajes,
	'unidad':unidad,
	'organizativa':organizativa,
	#~ 'unidades':unidades
	} , context_instance=RequestContext(request))
	



@login_required(login_url='/ingresar')
def mostrar_logs(request):
	id_unidad=request.session['unidad']
	unidad_mia=Unidad.objects.get(id=id_unidad)
	unidades = Unidad.objects.filter(subordinacion=request.session['unidad'])
	logs = Userlog.objects.all()
	usuarios=Perfil.objects.all()

	logs_unidad = []

	for log in logs:
		for usuario in usuarios:
			if usuario.user.username == log.usuario and (str(usuario.trabajador.plaza_ocupa.departamento.unidad.subordinacion) == str(unidad_mia) or str(usuario.trabajador.plaza_ocupa.departamento.unidad.id) == str(request.session['unidad'])):
				logs_unidad.append(log)


	return render_to_response('logs/ver_log_usuario.html',{'logs_unidad':logs_unidad}, context_instance=RequestContext(request))




#~ 
#~ def mostrar_logs(request):
	#~ unidades = Trabajador.objects.all()
	#~ user = User.objects.all()
#~ 
	#~ return render_to_response('logs/tra.html',{'user':user, 'unidades':unidades}, context_instance=RequestContext(request))
#~ 










#Contactanos
@login_required(login_url='/ingresar')
def contacto(request):
	
	return render_to_response('contacto.html' , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def lista_trabajador(request):
	id_unidad=request.session['unidad']
	organizativa = request.session['organizativa']
	unidad1= Unidad.objects.get(id=id_unidad)
	trabajadores = Trabajador.objects.filter(plaza_ocupa__departamento__unidad = id_unidad).order_by('-id')

	unidades= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')


	perfiles = Perfil.objects.all().order_by('-id')
	plazas = Plaza_Departamento.objects.filter(estado='vacia').order_by('-id')
	perfil={}
	plazas_disponibles={}
		
	for unidad in unidades: 
		for perfil1 in perfiles: 
			if unidad.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad.id]=unidad.id
		for plaza in plazas: 
			if unidad.id == plaza.departamento.unidad.id:
				plazas_disponibles[unidad.id]=unidad.id
	for plaza in plazas:
		if request.session['unidad'] == plaza.departamento.unidad.id:
			plazas_disponibles[request.session['unidad']]=request.session['unidad']
	return render_to_response('trabajador/index.trabajador.html',{'trabajadores':trabajadores,'unidades':unidades, 'unidad':unidad1, 'perfil':perfil,'plazas_disponibles':plazas_disponibles} , context_instance=RequestContext(request))



@login_required(login_url='/ingresar')
def listatrabajadorsub(request):
	organizativa = request.session['organizativa']

	id_unidad = request.GET.get('id')
	unidad1= Unidad.objects.get(id=id_unidad)
	trabajadores = Trabajador.objects.filter(plaza_ocupa__departamento__unidad = id_unidad).order_by('-id')


	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')

	perfiles = Perfil.objects.all().order_by('-id')
	plazas = Plaza_Departamento.objects.filter(estado='vacia').order_by('-id')
	perfil={}
	plazas_disponibles={}
		
	for unidad in unidades: 
		for perfil1 in perfiles: 
			if unidad.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad.id]=unidad.id
		for plaza in plazas: 
			if unidad.id == plaza.departamento.unidad.id:
				plazas_disponibles[unidad.id]=unidad.id
	for plaza in plazas:
		if request.session['unidad'] == plaza.departamento.unidad.id:
			plazas_disponibles[request.session['unidad']]=request.session['unidad']
	return render_to_response('trabajador/index.trabajador.html',{'trabajadores':trabajadores,'unidades':unidades, 'unidad':unidad1, 'perfil':perfil,'plazas_disponibles':plazas_disponibles} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def info_trabajador(request):

	organizativa = request.session['organizativa']
	id_trabajador = request.GET.get('id')
	trabajador=Trabajador.objects.get(id=id_trabajador)
	permiso=comprobar_perfil(request,trabajador.plaza_ocupa.departamento.unidad.id)
	if permiso ==2:
		return HttpResponseRedirect('/')
	editar=comprobar_perfil(request,trabajador.plaza_ocupa.departamento.unidad.id)
	return render_to_response('trabajador/info.trabajador.html',{
	'entity':trabajador,
	'editar':permiso,
	'organizativa':organizativa
	} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def form_editar_trabajador(request):
	plazas_departamentos = Plaza_Departamento.objects.all().order_by('-departamento')
	id_trabajador = request.GET.get('id')
	trabajador=Trabajador.objects.get(id=id_trabajador)
	permiso=comprobar_perfil(request,trabajador.plaza_ocupa.departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	old_plaza=trabajador.plaza_ocupa
	
	if request.method=='POST':
		form_trabajador = Formulario_Trabajador(request.POST, request.FILES, instance=trabajador)

		if form_trabajador.is_valid():

			form = form_trabajador.save(commit=False)
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			form.plaza_ocupa=new_plaza
			form.save()
			form_trabajador.save_m2m()
			if(new_plaza != old_plaza):
				new_plaza.estado="ocupado"
				old_plaza.estado="vacia"
				new_plaza.save()
				old_plaza.save()
			acciones='El trabajador '+ form.nombre + " fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('trabajador/info.trabajador.html',{'entity':form} , context_instance=RequestContext(request))
		else:
			unidad= old_plaza.departamento.unidad
	else:
		unidad=trabajador.plaza_ocupa.departamento.unidad
		form_trabajador = Formulario_Trabajador(instance=trabajador)
	return render_to_response('trabajador/editar.trabajador.html',{'form_trabajador':form_trabajador,'plazas_departamentos':plazas_departamentos,'unidad':unidad, 'trabajador':trabajador,} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def borrar_trabajador(request):
	id_trabajador = request.GET.get('id')
	trabajador = Trabajador.objects.get(id=id_trabajador)
	permiso=comprobar_perfil(request,trabajador.plaza_ocupa.departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	plaza=trabajador.plaza_ocupa
	perfil=Perfil.objects.filter(trabajador=trabajador)
	if len(perfil)>0:
		perfil[0].user.delete()
	trabajador.delete()
	
	plaza.estado='vacia'
	plaza.save()
	acciones='El trabajador '+ trabajador.nombre  + " del departamento "+ trabajador.plaza_ocupa.departamento.nombre.nombre + " de la Unidad "+ trabajador.plaza_ocupa.departamento.unidad.nombre+ " fue eliminado"
	registrar_log(request,acciones,3)

	return HttpResponseRedirect('lista_trabajador')


@login_required(login_url='/ingresar')
def agregar_trabajador(request):
	plazas_departamentos = Plaza_Departamento.objects.filter(departamento__unidad = request.session['unidad']).order_by('-departamento')
	if request.method=='POST':
		form_trabajador = Formulario_Trabajador(request.POST, request.FILES)
		
		if form_trabajador.is_valid():
			form = form_trabajador.save(commit=False)
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			new_plaza.estado="ocupada"
			form.plaza_ocupa=new_plaza
			form.estado = True
			form.save()
			form_trabajador.save_m2m()
			new_plaza.save()
			acciones='El trabajador '+ form.nombre + " del departamento "+ form.plaza_ocupa.departamento.nombre.nombre + " de la Unidad "+ form.plaza_ocupa.departamento.unidad.nombre+ " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('trabajador/info.trabajador.html',{'entity':form} , context_instance=RequestContext(request))
		else:
			new_plaza=Plaza_Departamento.objects.get(id=request.POST.get('plaza'))
			unidad= new_plaza.departamento.unidad
	else:
		id_unidad = request.GET.get('id')
		unidad=Unidad.objects.get(id=id_unidad)
		form_trabajador = Formulario_Trabajador()
	return render_to_response('trabajador/formulario.trabajador.html',{'form_trabajador':form_trabajador,'plazas_departamentos':plazas_departamentos,'unidad':unidad} , context_instance=RequestContext(request))

	
@login_required(login_url='/ingresar') 
def exportar_trabajador(request):

	id_trabajador=request.GET.get('id')

	trabajador= Trabajador.objects.get(id=id_trabajador)


	response = HttpResponse(content_type='application/pdf')
	pdf_name = "Expediente del Trabajor.pdf"  
	response['Content-Disposition'] = 'attachment; filename=%s' % pdf_name
	buff = BytesIO()

	doc = SimpleDocTemplate(buff,
							pagesize=portrait(letter),
							rightMargin=30,
							leftMargin=30,
							topMargin=15,
							bottomMargin=15,
							)

	expediente=[]
	styles = getSampleStyleSheet()
	styleSheet = getSampleStyleSheet()


#~ Portada
	I = Image("/var/www/pro/sii/Proyecto/comun/esculapio.png")
	I.drawHeight = 0.80*inch*I.drawHeight / I.drawWidth
	I.drawWidth = 0.80*inch

	I2 = Image("/var/www/pro/sii/Proyecto/comun/esculapio.png")
	I2.drawHeight = 0.80*inch*I.drawHeight / I.drawWidth
	I2.drawWidth = 0.80*inch


	Ti = Paragraph('''<para align=center><font size=16 ><b>Expediente Laboral </font></b><br>''',styleSheet["BodyText"])
	Un = Paragraph('''<para align=left><font size=12 ><b>Unidad en que trabaja: </b><font size=11>'''+trabajador.plaza_ocupa.departamento.unidad.nombre+' de '+ trabajador.plaza_ocupa.departamento.unidad.municipio.municipio+'''</font></font></para>''',styleSheet["BodyText"])
	
	trabajdor = Paragraph(string_concat('''<para align=left><font size=12 ><b>Nombre y Apellidos: </b> <font size=11>''',trabajador.nombre,' ''</font></font><br>'''),styleSheet["BodyText"])
	

	img= [
		['','',''],
		['',[I],'']
		]


	expediente.append(Ti)
	IMG = Table(img)
	expediente.append(IMG)
	expediente.append(trabajdor)
	expediente.append(Un)

	

	doc.build(expediente)
	response.write(buff.getvalue())
	buff.close()
	return response

