from django.forms import *
from django import forms
from unidad.models import *

class Formulario_Departamento(ModelForm):
	class Meta:
		model = Departamento
		exclude=('activo','unidad',)
		widgets = {
			'nombre': Select(attrs={'class' :'select2','placeholder': 'Nombre del Departamento'}),
			'telefono': TextInput(attrs={'class' :'form-control','placeholder': 'Telefono del  Departamento'}),
			'tipouorganizativa': Select(attrs={'class' :'select2','placeholder': 'Tipo de Unidad de Organizativa'}),
			}
			
class Formulario_Unidad(ModelForm):
	class Meta:
		model = Unidad
		exclude=('activo','subordinacion','nivel','perfil','tipo','municipio')
		widgets = {

			'nombre': TextInput(attrs={'class' :'form-control','placeholder': 'Nombre de la Unidad'}),
			'codigo': TextInput(attrs={'class' :'form-control','placeholder': 'Codigo de la Unidad'}),
			'direccion': TextInput(attrs={'class' :'form-control','placeholder': 'Direccion de la Unidad'}),
			'telefono': TextInput(attrs={'class' :'form-control','placeholder': 'Telefono de la Unidad'}),


			}

class Formulario_Plaza_Departamento(ModelForm):
	class Meta:
		model = Plaza_Departamento
		exclude=('activo','estado', 'departamento')
		widgets = {

			'plaza': Select(attrs={'class' :'select2','placeholder': 'Nombre de la Plaza','required':'true'}),
			'requerimiento': Textarea(attrs={'class' :'form-control','placeholder': 'Requerimientos','required':'true'}),
			}
