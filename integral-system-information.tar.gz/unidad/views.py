from django.shortcuts import render

# Create your views here.

from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from unidad.models import *
from rrhh.models import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from unidad.forms import Formulario_Departamento, Formulario_Unidad,  Formulario_Plaza_Departamento
from rrhh.forms import  Formulario_Trabajador
from django.db.models import Sum
from django.db.models import Count


from django.views.generic import UpdateView

#Unidades
@login_required(login_url='/ingresar')
def lista_unidad(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)
	unidades = "sd"  
	return render_to_response('unidad/index.unidad.html',{'unidades':unidades,'unidad':unidad}, context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def unidades_sub_unidad(request):
	id_unidad=request.session['unidad']
	unidad= Unidad.objects.get(id=id_unidad)
	
	unidades= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	for unidad1 in unidades: 
		for perfil1 in perfiles: 
			if unidad1.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad1.id]=unidad1.id
	return render_to_response('unidad/unidades.sub.unidad.html',{'unidades':unidades,'unidad':unidad, 'perfil':perfil}, context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def info_unidad(request):
	id_unidad = request.GET.get('id')
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2:
		return HttpResponseRedirect('/')
	unidad=Unidad.objects.filter(id=id_unidad)
	return render_to_response('unidad/info.unidad.html',{'entity':unidad[0],'editar':permiso} , context_instance=RequestContext(request))


@login_required(login_url='/ingresar')
def form_editar_unidad(request):
	id_unidad = request.GET.get('id')
	
	unidad=Unidad.objects.filter(id=id_unidad)
	permiso=comprobar_perfil(request,id_unidad)
	if permiso == 2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_unidad = Formulario_Unidad(request.POST, request.FILES,instance=unidad[0])
		if form_unidad.is_valid():
			form = form_unidad.save(commit=False)
			form.save()
			acciones='La Unidad '+ form.nombre + " de "+ form.municipio.municipio+ " fue editada"
			registrar_log(request,acciones,4)
			return render_to_response('unidad/info.unidad.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_unidad = Formulario_Unidad(instance=unidad[0])
	return render_to_response('unidad/editar.unidad.html',{'form_unidad':form_unidad, 'unidad':unidad[0]} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_unidad(request):
	id_unidad = request.GET.get('id')
	permiso=comprobar_perfil(request,id_unidad)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	unidad = Unidad.objects.get(id=id_unidad)
	unidad.delete()
	acciones='La Unidad '+ unidad.nombre + " de "+ unidad.municipio.municipio+ " fue eliminada"
	registrar_log(request,acciones,3)
	return HttpResponseRedirect('lista_unidad')


@login_required(login_url='/ingresar')
def agregar_unidad(request):
	if request.method=='POST':
		form_unidad = Formulario_Unidad(request.POST)
		if form_unidad.is_valid():
			form = form_unidad.save(commit=False)
			form.save()
			return render_to_response('unidad/info.unidad.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_unidad = Formulario_Unidad()
	return render_to_response('unidad/formulario.unidad.html',{'form_unidad':form_unidad} , context_instance=RequestContext(request))

#----------Departamento

@login_required(login_url='/ingresar')
def lista_departamento(request):
	if request.method=='POST':
		id_unidad = request.POST.get('id')
	else:
		id_unidad=request.session['unidad']

	unidad1= Unidad.objects.get(id=id_unidad)
	departamentos = Departamento.objects.annotate(cantidad=Count('plaza_departamento__id')).order_by('-id')
	departamentosunidad = Departamento.objects.filter(unidad=id_unidad).annotate(cantidad=Count('plaza_departamento'),cantidad_trabajadores=Count('plaza_departamento__trabajador_plaza'))  
	unidades= Unidad.objects.annotate(cantidad_plazas=Count('departamento__plaza_departamento'),cantidad_trabajadores=Count('departamento__plaza_departamento__trabajador_plaza')).filter(subordinacion=id_unidad).order_by('-municipio')
	perfiles = Perfil.objects.all().order_by('-id')
	perfil={}
	plazas_disponibles={}
	for unidad in unidades:
		plazas_disponibles[unidad.id]=unidad.cantidad_plazas-unidad.cantidad_trabajadores
		for perfil1 in perfiles: 
			if unidad.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad.id]=unidad.id
	if request.GET.get('msg'):
		msg=request.GET.get('msg')
	else:
		return render_to_response('departamento/index.departamento.html',{'departamentos':departamentos,'plazas_disponibles':plazas_disponibles,  'departamentosunidad':departamentosunidad,'unidades':unidades,'unidad':unidad1,'perfiles':perfiles, 'perfil':perfil} , context_instance=RequestContext(request))
	departamento = Departamento.objects.get(id=msg)
	mensaje='El departamento '+ departamento.nombre + ' tiene plazas habilitadas.'
	return render_to_response('departamento/index.departamento.html',{'departamentos':departamentos,'plazas_disponibles':plazas_disponibles,  'departamentosunidad':departamentosunidad,'unidades':unidades,'unidad':unidad1,'perfiles':perfiles, 'perfil':perfil,'mensaje':mensaje} , context_instance=RequestContext(request))



@login_required(login_url='/ingresar')
def info_departamento(request):
	id_departamento = request.GET.get('id')
	departamento=Departamento.objects.filter(id=id_departamento)
	permiso=comprobar_perfil(request,departamento[0].unidad.id)
	if permiso ==2:
		return HttpResponseRedirect('/')
	plazas=Plaza_Departamento.objects.filter(departamento=id_departamento).count()
	plazas1=Plaza_Departamento.objects.filter(departamento=id_departamento)
	trabajadores=0
	for plaza in plazas1:
		trabajador=Trabajador.objects.filter(plaza_ocupa=plaza).count()
		if trabajador !=0:
			trabajadores=trabajadores+1
	return render_to_response('departamento/info.departamento.html',{'entity':departamento[0],'plazas':plazas,'trabajadores':trabajadores,'editar':permiso} , context_instance=RequestContext(request))




@login_required(login_url='/ingresar')
def agregar_departamento(request):
	
	if request.method=='POST':
		form_departamento = Formulario_Departamento(request.POST)
		if form_departamento.is_valid():
			form = form_departamento.save(commit=False)
			new_unidad=Unidad.objects.get(id=request.POST.get('unidad'))
			form.unidad= new_unidad
			form.activo = True
			form.save()
			acciones='El departamento '+ form.nombre.nombre + " de la Unidad "+ form.unidad.nombre + " fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('departamento/info.departamento.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		id_unidad = request.GET.get('id')
		unidad=Unidad.objects.get(id=id_unidad)
		form_departamento = Formulario_Departamento()
	return render_to_response('departamento/formulario.departamento.html',{'form_departamento':form_departamento,'unidad':unidad} , context_instance=RequestContext(request))





@login_required(login_url='/ingresar')
def borrar_departamento(request):
	id_departamento = request.GET.get('id')
	departamento = Departamento.objects.get(id=id_departamento)
	permiso=comprobar_perfil(request,departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	if len(departamento.plaza_departamento.all())>0:
		
		return HttpResponseRedirect('lista_departamento?msg='+str(departamento.id))
	else:
		departamento.delete()
		acciones='El departamento '+ departamento.nombre.nombre + " de la Unidad "+ departamento.unidad.nombre + " fue eliminado"
		registrar_log(request,acciones,3)
	return HttpResponseRedirect('lista_departamento')




@login_required(login_url='/ingresar')
def form_editar_departamento(request):
	id_departamento = request.GET.get('id')
	departamento=Departamento.objects.filter(id=id_departamento)
	permiso=comprobar_perfil(request,departamento[0].unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_departamento= Formulario_Departamento(request.POST,instance=departamento[0])
		if form_departamento.is_valid():
			form = form_departamento.save(commit=False)
			form.save()
			#~ acciones='El departamento '+ form.nombre + " de la Unidad "+ form.unidad.nombre+ " fue editado"
			acciones="El departamento de la Unidad fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('departamento/info.departamento.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		form_departamento = Formulario_Departamento(instance=departamento[0])
	return render_to_response('departamento/editar.departamento.html',{'form_departamento':form_departamento, 'departamento':departamento} , context_instance=RequestContext(request))

#Plazas_Departamentos




@login_required(login_url='/ingresar')
def lista_plaza_departamento(request):
	if request.method=='POST':
		id_unidad = request.POST.get('id')
	else:
		id_unidad=request.session['unidad']

	a= Unidad.objects.get(id=id_unidad)
	unidad= Unidad.objects.get(id=id_unidad)


	plazas_departamentos = Plaza_Departamento.objects.filter(departamento__unidad=unidad.id).order_by('-departamento') 
	
	unidades= Unidad.objects.filter(subordinacion=unidad).order_by('-municipio')

	perfiles = Perfil.objects.all().order_by('-id')
	departamentos = Departamento.objects.filter(unidad=id_unidad).order_by('-id')
	perfil={}
	dpto={}
	for unidad in unidades: 
		for perfil1 in perfiles: 
			if unidad.id == perfil1.trabajador.plaza_ocupa.departamento.unidad.id:
				perfil[unidad.id]=unidad.id
		for departamento in departamentos: 
			if unidad.id == departamento.unidad.id:
				dpto[unidad.id]=unidad.id
	for departamento in departamentos:
		if id_unidad == departamento.unidad.id:
			dpto[id_unidad]=id_unidad
	return render_to_response('plaza_departamento/index.plaza_departamento.html',{
	'plazas_departamentos':plazas_departamentos, 
	'unidades':unidades, 
	'unidad':unidad, 
	'a':a, 
	'perfil':perfil,
	'dpto':dpto
	} , context_instance=RequestContext(request))








@login_required(login_url='/ingresar')
def info_plaza_departamento(request):
	id_plaza_departamento = request.GET.get('id')
	plaza_departamento=Plaza_Departamento.objects.filter(id=id_plaza_departamento)
	permiso=comprobar_perfil(request,plaza_departamento[0].departamento.unidad.id)
	if permiso ==2:
		return HttpResponseRedirect('/')
	return render_to_response('plaza_departamento/info.plaza_departamento.html',{'entity':plaza_departamento[0],'editar':permiso } , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def form_editar_plaza_departamento(request):
	id_plaza_departamento = request.GET.get('id')
	plaza_departamento=Plaza_Departamento.objects.get(id=id_plaza_departamento)
	permiso=comprobar_perfil(request,plaza_departamento.departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	if request.method=='POST':
		form_plaza_departamento = Formulario_Plaza_Departamento(request.POST,instance=plaza_departamento)
		if form_plaza_departamento.is_valid():
			form = form_plaza_departamento.save(commit=False)
			new_dpto=Departamento.objects.get(id=request.POST.get('departamento'))
			form.departamento= new_dpto
			form.save()
			#~ acciones="La plaza "+ form.plaza.plaza + "del departamento " + form.nombre+ " de la Unidad "+ form.unidad.nombre+ " fue editado"
			acciones="La plaza  del departamento  de la Unidad   fue editado"
			registrar_log(request,acciones,4)
			return render_to_response('plaza_departamento/info.plaza_departamento.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		
		departamentos = Departamento.objects.filter(unidad=plaza_departamento.departamento.unidad)  
		form_plaza_departamento = Formulario_Plaza_Departamento(instance=plaza_departamento)
	return render_to_response('plaza_departamento/editar.plaza_departamento.html',{'form_plaza_departamento':form_plaza_departamento,'departamentos':departamentos,'plaza_departamento':plaza_departamento} , context_instance=RequestContext(request))

@login_required(login_url='/ingresar')
def borrar_plaza_departamento(request):
	id_plaza_departamento = request.GET.get('id')
	plaza_departamento = Plaza_Departamento.objects.get(id=id_plaza_departamento)
	permiso=comprobar_perfil(request,plaza_departamento.departamento.unidad.id)
	if permiso ==2 or permiso == 0:
		return HttpResponseRedirect('/')
	if plaza_departamento.estado=='ocupado':
		return HttpResponseRedirect('lista_departamento?msg='+str(departamento.id))
	plaza_departamento.delete()
	#~ acciones="La plaza "+ plaza_departamento.plaza + "del departamento " + plaza_departamento.nombre.nombre + " de la Unidad "+ plaza_departamento.unidad.nombre+ " fue eliminado"
	acciones="La plaza del departamento de la Unidad fue eliminado"
	registrar_log(request,acciones,3)
	return HttpResponseRedirect('lista_plaza_departamento')
	
@login_required(login_url='/ingresar')
def agregar_plaza_departamento(request):
	if request.method=='POST':
		form_plaza_departamento = Formulario_Plaza_Departamento(request.POST)
		if form_plaza_departamento.is_valid():
			form = form_plaza_departamento.save(commit=False)
			new_dpto=Departamento.objects.get(id=request.POST.get('departamento'))
			form.departamento= new_dpto
			form.estado= 'vacia'
			form.activo = True
			form.save()
			acciones="La plaza del departamento fue agregado"
			registrar_log(request,acciones,2)
			return render_to_response('plaza_departamento/info.plaza_departamento.html',{'entity':form} , context_instance=RequestContext(request))
	else:
		id_unidad = request.GET.get('id')
		departamentos = Departamento.objects.filter(unidad=id_unidad)  
		form_plaza_departamento = Formulario_Plaza_Departamento()
	return render_to_response('plaza_departamento/formulario.plaza_departamento.html',{'form_plaza_departamento':form_plaza_departamento,'departamentos':departamentos } , context_instance=RequestContext(request))

#Registrar Logs
#num 1 iniciar session, 2 agregar, 3 eliminar, 4 editar, 5 cerrar session
@login_required(login_url='/ingresar')
def registrar_log(request,acciones,num):
	usuario=User.objects.get(id=request.session['userid'])
	perfil=Perfil.objects.get(user=usuario)
	user_log = Userlog()
	user_log.accion=acciones
	user_log.numaccion=num
	user_log.ip=request.META['REMOTE_ADDR']
	user_log.unidad=perfil.trabajador.plaza_ocupa.departamento.unidad.nombre
	
	user_log.departamento=perfil.trabajador.plaza_ocupa.departamento.nombre.nombre
	
	user_log.usuario= usuario.username
	user_log.save()




#Ver Logs de Usuario
@login_required(login_url='/ingresar')
def ver_log_usuario(request):
	logs = Userlog.objects.all().order_by('-fecha')
	usuarios=Perfil.objects.all().order_by('-user')
	cantidadlog={}
	ultimolog={}
	acceso={}
	print usuarios
	for usuario in usuarios:
		cantidadlog[usuario.user.id]=0
		ultimolog[usuario.user.id]='no ha accedido al sistema'
		acceso[usuario.user.id]=0
	
	for log in logs:
		for usuario in usuarios:
			if usuario.user.id == log.user.id:
				cantidadlog[usuario.user.id]=cantidadlog[usuario.user.id]+1
				if log.numaccion ==1:
					ultimolog[usuario.user.id]=log.fecha
					acceso[usuario.user.id]=acceso[usuario.user.id]+1
	return render_to_response('logs/ver_log_usuario.html',{'acceso':acceso,'usuarios':usuarios, 'cantidadlog':cantidadlog,'ultimolog':ultimolog  } , context_instance=RequestContext(request))

#Registrar Logs
#permiso = 0 Visualizar
#permiso = 1 Completo
#permiso = 2 Sin permiso
@login_required(login_url='/ingresar')
def comprobar_perfil(request,id_unidad):
	mi_unidad=Unidad.objects.get(id=id_unidad)
	
	permiso=1
	if str(id_unidad) == str(request.session['unidad']):
		permiso=1
	else:
		if(mi_unidad and mi_unidad.subordinacion):
			if str(mi_unidad.subordinacion.id) != str(request.session['unidad']):
				permiso=2
			else:
				perfiles=Perfil.objects.all()
				for perf in perfiles:
					if str(perf.trabajador.plaza_ocupa.departamento.unidad.id) == str(id_unidad) :
						permiso=0
		else:
			permiso=2
	return permiso



def reporte(request):
	dpto=Departamento.objects.all()
	return render_to_response('alfa.html',{'dpto':dpto} , context_instance=RequestContext(request))

