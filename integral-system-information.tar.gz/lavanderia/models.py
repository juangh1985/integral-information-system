from django.db import models
from unidad.models import *

class producto(models.Model):
	nombre=models.CharField('Producto',max_length=30,blank=True,null=True)
	def __unicode__(self):
		return '%s' % (self.nombre)


class reporte(models.Model):
	producto=models.ForeignKey(producto,max_length=30,blank=True,null=True)
	unidad=models.ForeignKey(Unidad,max_length=30,blank=True,null=True)
	cantidad=models.IntegerField('Cantidad',max_length=30,blank=True,null=True)
	fecha= models.DateTimeField('Fecha de Reporte',auto_now=False, auto_now_add=False, blank=True, null=True)
	actualizacion= models.DateTimeField('Actualizado',auto_now=True, auto_now_add=True)




