from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext

from alimentos.models import *
from lavanderia.models import *
from lavanderia.forms import *

from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.db.models import Count

def inicio(request):
	lav = reporte.objects.all()
	ali = alimentos.objects.all()
	return render_to_response('portada.html',{
	'lav':lav,
	'ali':ali,
	}, context_instance=RequestContext(request))











def listar(request):
	informe = reporte.objects.all()
	return render_to_response('reporte/reporte.html',{
	'informe':informe,
	}, context_instance=RequestContext(request))
	
	
def eliminar(request):
	id = request.GET.get('id_reporte')
	auto = reporte.objects.get(id=id)
	auto.delete()
	return HttpResponseRedirect('/listalavanderia')

	
def agregar(request):
	if request.method=='POST':
		form_reporte = formulario_reporte(request.POST, request.FILES)
		if form_reporte.is_valid():
			form = form_reporte.save(commit=False)
			form.save()
			return HttpResponseRedirect('/listalavanderia')
	else:
		form_reporte = formulario_reporte()
	return render_to_response('reporte/formulario.reporte.html',{'form_reporte':form_reporte} , context_instance=RequestContext(request))


