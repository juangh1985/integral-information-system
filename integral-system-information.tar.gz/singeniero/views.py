#!/usr/bin/python
# -*- coding: utf-8 -*-

from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext

from rrhh.models import *
from unidad.models import *
from unidad.views import *
from singeniero.models import *
from singeniero.forms import *

from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.db.models import Count







############################
##    CRUD ASCENSOR
############################

def lista_ascensor(request):

	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')

	unidades= Unidad.objects.annotate(cantidad=Count('ascensor')).filter(subordinacion=id_unidad).order_by('-municipio')


	filtro=Unidad.objects.get(id=id_unidad)
	informe = ascensor.objects.filter(unidad=filtro)

### para generar los graficos nacionales y por unidad.
	todo = ascensor.objects.all().count()
	todotrue = ascensor.objects.filter(activo=True).count()

	informetotal = ascensor.objects.filter(unidad=filtro).count()
	informetrue = ascensor.objects.filter(unidad=filtro, activo=True).count()
########################################################




	return render_to_response('ascensor/ascensor.html',{

	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_ascensor(request):
	id = request.GET.get('id_reporte')
	auto = ascensor.objects.get(id=id)
	auto.delete()

	r = Userlog(usuario = request.session['userid'], unidad =  request.session['unidad'], departamento = request.session['organizativa'], trabajador = request.session['nombre'], accion = 'Elimino al elemento' + str(auto), numaccion = '3', ip = '3')
	r.save()

	return HttpResponseRedirect('/ascensor')


def form_ascensor(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	if request.method=='POST':
		form_ascensor = formulario_ascensor(request.POST, request.FILES)
		if form_ascensor.is_valid():
			form = form_ascensor.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/ascensor')
	else:
		form_ascensor = formulario_ascensor()
	return render_to_response('ascensor/formulario.ascensor.html',{'form_ascensor':form_ascensor} , context_instance=RequestContext(request))


def editar_ascensor(request):
	id_equipo = request.GET.get('id')
	auto = ascensor.objects.get(id=id_equipo)
	informe = ascensor.objects.all()

	if request.method=='POST':
		form_ascensor = formulario_ascensor(request.POST,instance=auto)
		if form_ascensor.is_valid():
			form = form_ascensor.save(commit=False)
			form.save()
			return HttpResponseRedirect('/ascensor')
	else:
		form_ascensor = formulario_ascensor(instance=auto)
	return render_to_response('ascensor/formulario.ascensor.html',{'form_ascensor':form_ascensor,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD ASCENSOR
############################













############################
##    CRUD calderas
############################

def lista_calderas(request):


	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = calderas.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = calderas.objects.all().count()
	todotrue = calderas.objects.filter(activo=True).count()

	informetotal = calderas.objects.filter(unidad=filtro).count()
	informetrue = calderas.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('calderas/calderas.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_calderas(request):
	id = request.GET.get('id_reporte')
	auto = calderas.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/calderas')


def form_calderas(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	if request.method=='POST':
		form_calderas = formulario_calderas(request.POST, request.FILES)
		if form_calderas.is_valid():
			form = form_calderas.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/calderas')
	else:
		form_calderas = formulario_calderas()
	return render_to_response('calderas/formulario.calderas.html',{'form_calderas':form_calderas} , context_instance=RequestContext(request))


def editar_calderas(request):
	id_equipo = request.GET.get('id')
	auto = calderas.objects.get(id=id_equipo)
	informe = calderas.objects.all()

	if request.method=='POST':
		form_calderas = formulario_calderas(request.POST,instance=auto)
		if form_calderas.is_valid():
			form = form_calderas.save(commit=False)
			form.save()
			return HttpResponseRedirect('/calderas')
	else:
		form_calderas = formulario_calderas(instance=auto)
	return render_to_response('calderas/formulario.calderas.html',{'form_calderas':form_calderas,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD calderas
############################




############################
##    CRUD compresor
############################

def lista_compresor(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = compresor.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = compresor.objects.all().count()
	todotrue = compresor.objects.filter(activo=True).count()

	informetotal = compresor.objects.filter(unidad=filtro).count()
	informetrue = compresor.objects.filter(unidad=filtro, activo=True).count()
########################################################




	return render_to_response('compresor/compresor.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_compresor(request):
	id = request.GET.get('id_reporte')
	auto = compresor.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/compresor')


def form_compresor(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_compresor = formulario_compresor(request.POST, request.FILES)
		if form_compresor.is_valid():
			form = form_compresor.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/compresor')
	else:
		form_compresor = formulario_compresor()
	return render_to_response('compresor/formulario.compresor.html',{'form_compresor':form_compresor} , context_instance=RequestContext(request))


def editar_compresor(request):
	id_equipo = request.GET.get('id')
	auto = compresor.objects.get(id=id_equipo)
	informe = compresor.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_compresor = formulario_compresor(request.POST,instance=auto)
		if form_compresor.is_valid():
			form = form_compresor.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/compresor')
	else:
		form_compresor = formulario_compresor(instance=auto)
	return render_to_response('compresor/formulario.compresor.html',{'form_compresor':form_compresor,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD compresor
############################


############################
##    CRUD bomba_agua_fria
############################

def lista_bomba_agua_fria(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = bomba_agua_fria.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = bomba_agua_fria.objects.all().count()
	todotrue = bomba_agua_fria.objects.filter(activo=True).count()

	informetotal = bomba_agua_fria.objects.filter(unidad=filtro).count()
	informetrue = bomba_agua_fria.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('bomba_agua_fria/bomba_agua_fria.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_bomba_agua_fria(request):
	id = request.GET.get('id_reporte')
	auto = bomba_agua_fria.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/bomba_agua_fria')


def form_bomba_agua_fria(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_bomba_agua_fria = formulario_bomba_agua_fria(request.POST, request.FILES)
		if form_bomba_agua_fria.is_valid():
			form = form_bomba_agua_fria.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/bomba_agua_fria')
	else:
		form_bomba_agua_fria = formulario_bomba_agua_fria()
	return render_to_response('bomba_agua_fria/formulario.bomba_agua_fria.html',{'form_bomba_agua_fria':form_bomba_agua_fria} , context_instance=RequestContext(request))


def editar_bomba_agua_fria(request):
	id_equipo = request.GET.get('id')
	auto = bomba_agua_fria.objects.get(id=id_equipo)
	informe = bomba_agua_fria.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_bomba_agua_fria = formulario_bomba_agua_fria(request.POST,instance=auto)
		if form_bomba_agua_fria.is_valid():
			form = form_bomba_agua_fria.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/bomba_agua_fria')
	else:
		form_bomba_agua_fria = formulario_bomba_agua_fria(instance=auto)
	return render_to_response('bomba_agua_fria/formulario.bomba_agua_fria.html',{'form_bomba_agua_fria':form_bomba_agua_fria,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD bomba_agua_fria
############################






############################
##    CRUD manejadoras
############################

def lista_manejadoras(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = manejadoras.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = manejadoras.objects.all().count()
	todotrue = manejadoras.objects.filter(activo=True).count()

	informetotal = manejadoras.objects.filter(unidad=filtro).count()
	informetrue = manejadoras.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('manejadoras/manejadoras.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_manejadoras(request):
	id = request.GET.get('id_reporte')
	auto = manejadoras.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/manejadoras')


def form_manejadoras(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_manejadoras = formulario_manejadoras(request.POST, request.FILES)
		if form_manejadoras.is_valid():
			form = form_manejadoras.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/manejadoras')
	else:
		form_manejadoras = formulario_manejadoras()
	return render_to_response('manejadoras/formulario.manejadoras.html',{'form_manejadoras':form_manejadoras} , context_instance=RequestContext(request))


def editar_manejadoras(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	id_equipo = request.GET.get('id')
	auto = manejadoras.objects.get(id=id_equipo)
	informe = manejadoras.objects.all()

	if request.method=='POST':
		form_manejadoras = formulario_manejadoras(request.POST,instance=auto)
		if form_manejadoras.is_valid():
			form = form_manejadoras.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/manejadoras')
	else:
		form_manejadoras = formulario_manejadoras(instance=auto)
	return render_to_response('manejadoras/formulario.manejadoras.html',{'form_manejadoras':form_manejadoras,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD manejadoras
############################






############################
##    CRUD extractores
############################

def lista_extractores(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = extractores.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = extractores.objects.all().count()
	todotrue = extractores.objects.filter(activo=True).count()

	informetotal = extractores.objects.filter(unidad=filtro).count()
	informetrue = extractores.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('extractores/extractores.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_extractores(request):
	id = request.GET.get('id_reporte')
	auto = extractores.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/extractores')


def form_extractores(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_extractores = formulario_extractores(request.POST, request.FILES)
		if form_extractores.is_valid():
			form = form_extractores.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/extractores')
	else:
		form_extractores = formulario_extractores()
	return render_to_response('extractores/formulario.extractores.html',{'form_extractores':form_extractores} , context_instance=RequestContext(request))


def editar_extractores(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	id_equipo = request.GET.get('id')
	auto = extractores.objects.get(id=id_equipo)
	informe = extractores.objects.all()

	if request.method=='POST':
		form_extractores = formulario_extractores(request.POST,instance=auto)
		if form_extractores.is_valid():
			form = form_extractores.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/extractores')
	else:
		form_extractores = formulario_extractores(instance=auto)
	return render_to_response('extractores/formulario.extractores.html',{'form_extractores':form_extractores,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD extractoresascensor
############################






############################
##    CRUD clima_expansion_directa
############################

def lista_clima_expansion_directa(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = clima_expansion_directa.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = clima_expansion_directa.objects.all().count()
	todotrue = clima_expansion_directa.objects.filter(activo=True).count()

	informetotal = clima_expansion_directa.objects.filter(unidad=filtro).count()
	informetrue = clima_expansion_directa.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('clima_expansion_directa/clima_expansion_directa.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_clima_expansion_directa(request):
	id = request.GET.get('id_reporte')
	auto = clima_expansion_directa.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/clima_expansion_directa')


def form_clima_expansion_directa(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_clima_expansion_directa = formulario_clima_expansion_directa(request.POST, request.FILES)
		if form_clima_expansion_directa.is_valid():
			form = form_clima_expansion_directa.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/clima_expansion_directa')
	else:
		form_clima_expansion_directa = formulario_clima_expansion_directa()
	return render_to_response('clima_expansion_directa/formulario.clima_expansion_directa.html',{'form_clima_expansion_directa':form_clima_expansion_directa} , context_instance=RequestContext(request))


def editar_clima_expansion_directa(request):
	id_equipo = request.GET.get('id')
	auto = clima_expansion_directa.objects.get(id=id_equipo)
	informe = clima_expansion_directa.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_clima_expansion_directa = formulario_clima_expansion_directa(request.POST,instance=auto)
		if form_clima_expansion_directa.is_valid():
			form = form_clima_expansion_directa.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/clima_expansion_directa')
	else:
		form_clima_expansion_directa = formulario_clima_expansion_directa(instance=auto)
	return render_to_response('clima_expansion_directa/formulario.clima_expansion_directa.html',{'form_clima_expansion_directa':form_clima_expansion_directa,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD clima_expansion_directa
############################


############################
##    CRUD bomba_agua
############################

def lista_bomba_agua(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')

	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = bomba_agua.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = bomba_agua.objects.all().count()
	todotrue = bomba_agua.objects.filter(activo=True).count()

	informetotal = bomba_agua.objects.filter(unidad=filtro).count()
	informetrue = bomba_agua.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('bomba_agua/bomba_agua.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_bomba_agua(request):
	id = request.GET.get('id_reporte')
	auto = bomba_agua.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/bomba_agua')


def form_bomba_agua(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_bomba_agua = formulario_bomba_agua(request.POST, request.FILES)
		if form_bomba_agua.is_valid():
			form = form_bomba_agua.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/bomba_agua')
	else:
		form_bomba_agua = formulario_bomba_agua()
	return render_to_response('bomba_agua/formulario.bomba_agua.html',{'form_bomba_agua':form_bomba_agua} , context_instance=RequestContext(request))


def editar_bomba_agua(request):
	id_equipo = request.GET.get('id')
	auto = bomba_agua.objects.get(id=id_equipo)
	informe = bomba_agua.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_bomba_agua = formulario_bomba_agua(request.POST,instance=auto)
		if form_bomba_agua.is_valid():
			form = form_bomba_agua.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/bomba_agua')
	else:
		form_bomba_agua = formulario_bomba_agua(instance=auto)
	return render_to_response('bomba_agua/formulario.bomba_agua.html',{'form_bomba_agua':form_bomba_agua,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD bomba_agua
############################

############################
##    CRUD equipo_cocina
############################

def lista_equipo_cocina(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = equipo_cocina.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = equipo_cocina.objects.all().count()
	todotrue = equipo_cocina.objects.filter(activo=True).count()

	informetotal = equipo_cocina.objects.filter(unidad=filtro).count()
	informetrue = equipo_cocina.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('equipo_cocina/equipo_cocina.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_equipo_cocina(request):
	id = request.GET.get('id_reporte')
	auto = equipo_cocina.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/equipo_cocina')


def form_equipo_cocina(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_equipo_cocina = formulario_equipo_cocina(request.POST, request.FILES)
		if form_equipo_cocina.is_valid():
			form = form_equipo_cocina.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/equipo_cocina')
	else:
		form_equipo_cocina = formulario_equipo_cocina()
	return render_to_response('equipo_cocina/formulario.equipo_cocina.html',{'form_equipo_cocina':form_equipo_cocina} , context_instance=RequestContext(request))


def editar_equipo_cocina(request):
	id_equipo = request.GET.get('id')
	auto = equipo_cocina.objects.get(id=id_equipo)
	informe = equipo_cocina.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_equipo_cocina = formulario_equipo_cocina(request.POST,instance=auto)
		if form_equipo_cocina.is_valid():
			form = form_equipo_cocina.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/equipo_cocina')
	else:
		form_equipo_cocina = formulario_equipo_cocina(instance=auto)
	return render_to_response('equipo_cocina/formulario.equipo_cocina.html',{'form_equipo_cocina':form_equipo_cocina,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD equipo_cocina
############################





############################
##    CRUD equipo_lavanderia
############################

def lista_equipo_lavanderia(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = equipo_lavanderia.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = equipo_lavanderia.objects.all().count()
	todotrue = equipo_lavanderia.objects.filter(activo=True).count()

	informetotal = equipo_lavanderia.objects.filter(unidad=filtro).count()
	informetrue = equipo_lavanderia.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('equipo_lavanderia/equipo_lavanderia.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_equipo_lavanderia(request):
	id = request.GET.get('id_reporte')
	auto = equipo_lavanderia.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/equipo_lavanderia')


def form_equipo_lavanderia(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_equipo_lavanderia = formulario_equipo_lavanderia(request.POST, request.FILES)
		if form_equipo_lavanderia.is_valid():
			form = form_equipo_lavanderia.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/equipo_lavanderia')
	else:
		form_equipo_lavanderia = formulario_equipo_lavanderia()
	return render_to_response('equipo_lavanderia/formulario.equipo_lavanderia.html',{'form_equipo_lavanderia':form_equipo_lavanderia} , context_instance=RequestContext(request))


def editar_equipo_lavanderia(request):
	id_equipo = request.GET.get('id')
	auto = equipo_lavanderia.objects.get(id=id_equipo)
	informe = equipo_lavanderia.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_equipo_lavanderia = formulario_equipo_lavanderia(request.POST,instance=auto)
		if form_equipo_lavanderia.is_valid():
			form = form_equipo_lavanderia.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/equipo_lavanderia')
	else:
		form_equipo_lavanderia = formulario_equipo_lavanderia(instance=auto)
	return render_to_response('equipo_lavanderia/formulario.equipo_lavanderia.html',{'form_equipo_lavanderia':form_equipo_lavanderia,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD equipo_lavanderia
############################




############################
##    CRUD grupo_electrogeno
############################

def lista_grupo_electrogeno(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')

	unidades= Unidad.objects.annotate(cantidad=Count('grupo_electrogeno')).filter(subordinacion=id_unidad).order_by('-municipio')





	filtro=Unidad.objects.get(id=id_unidad)
	informe = grupo_electrogeno.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = grupo_electrogeno.objects.all().count()
	todotrue = grupo_electrogeno.objects.filter(activo=True).count()

	informetotal = grupo_electrogeno.objects.filter(unidad=filtro).count()
	informetrue = grupo_electrogeno.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('grupo_electrogeno/grupo_electrogeno.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_grupo_electrogeno(request):
	id = request.GET.get('id_reporte')
	auto = grupo_electrogeno.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/grupo_electrogeno')


def form_grupo_electrogeno(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_grupo_electrogeno = formulario_grupo_electrogeno(request.POST, request.FILES)
		if form_grupo_electrogeno.is_valid():
			form = form_grupo_electrogeno.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/grupo_electrogeno')
	else:
		form_grupo_electrogeno = formulario_grupo_electrogeno()
	return render_to_response('grupo_electrogeno/formulario.grupo_electrogeno.html',{'form_grupo_electrogeno':form_grupo_electrogeno} , context_instance=RequestContext(request))


def editar_grupo_electrogeno(request):
	id_equipo = request.GET.get('id')
	auto = grupo_electrogeno.objects.get(id=id_equipo)
	informe = grupo_electrogeno.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_grupo_electrogeno = formulario_grupo_electrogeno(request.POST,instance=auto)
		if form_grupo_electrogeno.is_valid():
			form = form_grupo_electrogeno.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/grupo_electrogeno')
	else:
		form_grupo_electrogeno = formulario_grupo_electrogeno(instance=auto)
	return render_to_response('grupo_electrogeno/formulario.grupo_electrogeno.html',{'form_grupo_electrogeno':form_grupo_electrogeno,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD grupo_electrogeno
############################



############################
##    CRUD campana_extraccion_gases
############################

def lista_campana_extraccion_gases(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = campana_extraccion_gases.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = campana_extraccion_gases.objects.all().count()
	todotrue = campana_extraccion_gases.objects.filter(activo=True).count()

	informetotal = campana_extraccion_gases.objects.filter(unidad=filtro).count()
	informetrue = campana_extraccion_gases.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('campana_extraccion_gases/campana_extraccion_gases.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_campana_extraccion_gases(request):
	id = request.GET.get('id_reporte')
	auto = campana_extraccion_gases.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/campana_extraccion_gases')


def form_campana_extraccion_gases(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_campana_extraccion_gases = formulario_campana_extraccion_gases(request.POST, request.FILES)
		if form_campana_extraccion_gases.is_valid():
			form = form_campana_extraccion_gases.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/campana_extraccion_gases')
	else:
		form_campana_extraccion_gases = formulario_campana_extraccion_gases()
	return render_to_response('campana_extraccion_gases/formulario.campana_extraccion_gases.html',{'form_campana_extraccion_gases':form_campana_extraccion_gases} , context_instance=RequestContext(request))


def editar_campana_extraccion_gases(request):
	id_equipo = request.GET.get('id')
	auto = campana_extraccion_gases.objects.get(id=id_equipo)
	informe = campana_extraccion_gases.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_campana_extraccion_gases = formulario_campana_extraccion_gases(request.POST,instance=auto)
		if form_campana_extraccion_gases.is_valid():
			form = form_campana_extraccion_gases.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/campana_extraccion_gases')
	else:
		form_campana_extraccion_gases = formulario_campana_extraccion_gases(instance=auto)
	return render_to_response('campana_extraccion_gases/formulario.campana_extraccion_gases.html',{'form_campana_extraccion_gases':form_campana_extraccion_gases,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD campana_extraccion_gases
############################


############################
##    CRUD ventilador
############################

def lista_ventilador(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = ventilador.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = ventilador.objects.all().count()
	todotrue = ventilador.objects.filter(activo=True).count()

	informetotal = ventilador.objects.filter(unidad=filtro).count()
	informetrue = ventilador.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('ventilador/ventilador.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_ventilador(request):
	id = request.GET.get('id_reporte')
	auto = ventilador.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/ventilador')


def form_ventilador(request):
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_ventilador = formulario_ventilador(request.POST, request.FILES)
		if form_ventilador.is_valid():
			form = form_ventilador.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/ventilador')
	else:
		form_ventilador = formulario_ventilador()
	return render_to_response('ventilador/formulario.ventilador.html',{'form_ventilador':form_ventilador} , context_instance=RequestContext(request))


def editar_ventilador(request):
	id_equipo = request.GET.get('id')
	auto = ventilador.objects.get(id=id_equipo)
	informe = ventilador.objects.all()
	filtro=Unidad.objects.get(id=request.session['unidad'])

	if request.method=='POST':
		form_ventilador = formulario_ventilador(request.POST,instance=auto)
		if form_ventilador.is_valid():
			form = form_ventilador.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/ventilador')
	else:
		form_ventilador = formulario_ventilador(instance=auto)
	return render_to_response('ventilador/formulario.ventilador.html',{'form_ventilador':form_ventilador,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD ventilador
############################

############################
##    CRUD panel_solar
############################

def lista_panel_solar(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=id_unidad)
	informe = panel_solar.objects.filter(unidad=filtro)
### para generar los graficos nacionales y por unidad.
	todo = panel_solar.objects.all().count()
	todotrue = panel_solar.objects.filter(activo=True).count()

	informetotal = panel_solar.objects.filter(unidad=filtro).count()
	informetrue = panel_solar.objects.filter(unidad=filtro, activo=True).count()
########################################################
	return render_to_response('panel_solar/panel_solar.html',{
	'todo':todo,
	'todotrue':todotrue,
	'informetotal':informetotal,
	'informetrue':informetrue,
	'informe':informe,
	'unidades':unidades,
	'filtro':filtro,
	}, context_instance=RequestContext(request))


def eliminar_panel_solar(request):
	id = request.GET.get('id_reporte')
	auto = panel_solar.objects.get(id=id)
	auto.delete()

	return HttpResponseRedirect('/panel_solar')


def form_panel_solar(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=request.session['unidad'])
	if request.method=='POST':
		form_panel_solar = formulario_panel_solar(request.POST, request.FILES)
		if form_panel_solar.is_valid():
			form = form_panel_solar.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/panel_solar')
	else:
		form_panel_solar = formulario_panel_solar()
	return render_to_response('panel_solar/formulario.panel_solar.html',{'form_panel_solar':form_panel_solar} , context_instance=RequestContext(request))


def editar_panel_solar(request):
	if request.POST.get('id') == None:
		id_unidad=request.session['unidad']
	else:
		id_unidad = request.POST.get('id')
	unidades= Unidad.objects.filter(subordinacion=id_unidad).order_by('-municipio')
	filtro=Unidad.objects.get(id=request.session['unidad'])

	id_equipo = request.GET.get('id')
	auto = panel_solar.objects.get(id=id_equipo)
	informe = panel_solar.objects.all()

	if request.method=='POST':
		form_panel_solar = formulario_panel_solar(request.POST,instance=auto)
		if form_panel_solar.is_valid():
			form = form_panel_solar.save(commit=False)
			form.unidad = filtro
			form.save()
			return HttpResponseRedirect('/panel_solar')
	else:
		form_panel_solar = formulario_panel_solar(instance=auto)
	return render_to_response('panel_solar/formulario.panel_solar.html',{'form_panel_solar':form_panel_solar,'auto':auto,} , context_instance=RequestContext(request))


############################
##    FIN CRUD panel_solar
############################
