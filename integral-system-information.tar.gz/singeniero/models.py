#!/usr/bin/python
# -*- coding: utf-8 -*-
from django.db import models
from unidad.models import Unidad


class estado(models.Model):
	estado = models.CharField('Estados', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.estado)

class tipo_ascensor(models.Model):
	tipo = models.CharField('Tipo de Ascensor', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.tipo)


class tipo_grupo_electrogeno(models.Model):
	tipo = models.CharField('Tipo de Grupo', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.tipo)
class marca_grupo_electrogeno(models.Model):
	tipo = models.CharField('Marca de Grupo', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.tipo)


class serviciador_grupo_electrogeno(models.Model):
	tipo = models.CharField('Serviciador de Grupo', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.tipo)



###### OK ######
class marca_ascensor(models.Model):
	marca = models.CharField('Marca de Ascensor', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.marca)
###### OK ######

###### OK ######
class marca_bomba(models.Model):
	marca = models.CharField('Marca de Bomba', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.marca)
###### OK ######

class tipo_refrigerante(models.Model):
	tipo = models.CharField('Tipo de Ascensor', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)


class tipo_compresor(models.Model):
	tipo = models.CharField('Tipo de Ascensor', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)


class tipo_filtro(models.Model):
	tipo = models.CharField('Tipo de Ascensor', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)


class tipo_ced(models.Model):
	tipo = models.CharField('Tipo de Ascensor', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)


class tipo_bomba(models.Model):
	tipo = models.CharField('Tipo de Ascensor', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)

class tipo_camara_fria(models.Model):
	tipo = models.CharField('Tipo de Cámara Fría', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)

class tipo_ventilador(models.Model):
	tipo = models.CharField('Tipo de Ventilador', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)

class tipo_sistema(models.Model):
	tipo = models.CharField('Tipo de Sistema del Equipo de Cocina', blank=True, max_length=256, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)

###### OK ######
class tipo_balas(models.Model):
	tipo = models.CharField('Tipo de Bala', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.tipo)
###### OK ######



###### OK ######
###################LISTO##################
class ascensor(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	fabricacion = models.CharField('Fabricacion', max_length=256, blank=True, null=True)
	tipo_ascensor = models.ForeignKey(tipo_ascensor, blank=True, max_length=256, null=True)
	marca_ascensor = models.ForeignKey(marca_ascensor, blank=True, max_length=256, null=True)
	capacidad = models.FloatField('Capacidad (kg)', max_length=256, blank=True, null=True)
	cantidad_paradas = models.SmallIntegerField('Cantidad de Paradas', max_length=256, blank=True, null=True)
	velocidad = models.FloatField('Velocidad (m/s)', max_length=256, blank=True, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	observacion = models.CharField('Observacion', max_length=2048, blank=True, null=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.tipo_ascensor, '-', self.ni)
####################################
###### OK ######










###################LISTO##################
class calderas(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	capacidad = models.FloatField('Capacidad (kg)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.ni)
####################################

class clima_centralizado(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.unidad)


class enfriadora(models.Model):
	clima_centralizado = models.ForeignKey(clima_centralizado, blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.clima_centralizado)

###################LISTO##################
class compresor(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	enfriadora = models.ForeignKey(enfriadora, blank=True, max_length=256, null=True)
	tipo_refrigerante = models.ForeignKey(tipo_refrigerante, blank=True, max_length=256, null=True)
	cantidad_refrigerante = models.FloatField('Cantidad de Refrigerante (lb)', max_length=256, blank=True, null=True)
	tipo_compresor = models.ForeignKey(tipo_compresor, blank=True, max_length=256, null=True)
	capacidad_enfriamiento = models.FloatField('Capacidad de Enfriamiento(TR)', max_length=256, blank=True, null=True)
	caudal = models.FloatField('Caudal de agua a enfriar (m3/s)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.tipo_compresor, '-', self.ni)
####################################

###################LISTO##################
class bomba_agua_fria(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	enfriadora = models.ForeignKey(enfriadora, blank=True, max_length=256, null=True)
	caudal = models.FloatField('Caudal de agua a enfriar (m3/s)', max_length=256, blank=True, null=True)
	altura = models.FloatField('Altura (m)', max_length=256, blank=True, null=True)
	potencia = models.FloatField('Potencia (kW)', max_length=256, blank=True, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)
	velocidad_rotacion = models.FloatField('Velocidad de Rotación (rpm)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.ni)
####################################

###################LISTO##################
class manejadoras(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	clima_centralizado = models.ForeignKey(clima_centralizado, blank=True, max_length=256, null=True)
	tipo_filtro = models.ForeignKey(tipo_filtro, blank=True, max_length=256, null=True)
	dimensiones_filtro = models.CharField('Dimensiones del Filtro (mm)', max_length=256, blank=True, null=True)
	capacidad_enfriamiento = models.FloatField('Capacidad Total de Enfriamiento (TR)', max_length=256, blank=True, null=True)
	caudal = models.FloatField('Caudal de agua a enfriar (m3/s)', max_length=256, blank=True, null=True)
	potencia = models.FloatField('Potencia (kW)', max_length=256, blank=True, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
####################################

###################LISTO##################
class extractores(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	clima_centralizado = models.ForeignKey(clima_centralizado, blank=True, max_length=256, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	caudal = models.FloatField('Caudal de agua a enfriar (m3/s)', max_length=256, blank=True, null=True)
	presion = models.FloatField('Presión (mm.ca)', max_length=256, blank=True, null=True)
	potencia = models.FloatField('Potencia (kW)', max_length=256, blank=True, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
####################################

###################LISTO##################
class clima_expansion_directa(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	tipo_ced = models.ForeignKey(tipo_ced, blank=True, max_length=256, null=True)
	capacidad = models.FloatField('Capacidad (TR)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.tipo_ced, '-', self.ni)
####################################





class camaras_frias(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	tipo_camara_fria = models.ForeignKey(tipo_camara_fria, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.id, '-', self.unidad)

class panelizacion_camaras_frias(models.Model):
	camaras_frias = models.ForeignKey(camaras_frias, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	largo = models.FloatField('Largo (m)', max_length=256, blank=True, null=True)
	ancho = models.FloatField('Ancho (m)', max_length=256, blank=True, null=True)
	altura = models.FloatField('Altura (m)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)


class equipamiento_camaras_frias(models.Model):
	camaras_frias = models.ForeignKey(camaras_frias, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	capacidad = models.FloatField('Capacidad (TR, BTU, kW)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', super.unidad)


class camaras_modular(models.Model):
	camaras_frias = models.ForeignKey(camaras_frias, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	largo = models.FloatField('Largo (m)', max_length=256, blank=True, null=True)
	ancho = models.FloatField('Ancho (m)', max_length=256, blank=True, null=True)
	altura = models.FloatField('Altura (m)', max_length=256, blank=True, null=True)
	capacidad = models.FloatField('Capacidad (TR, BTU, kW)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)



###### OK ######
###################LISTO##################
class bomba_agua(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	tipo_bomba = models.ForeignKey(tipo_bomba, blank=True, null=True)
	marca_bomba = models.ForeignKey(marca_bomba, blank=True, null=True)
	caudal = models.FloatField('Caudal de agua a enfriar (m3/s)', max_length=256, blank=True, null=True)
	altura = models.FloatField('Altura (m)', max_length=256, blank=True, null=True)
	potencia = models.FloatField('Potencia (kW)', max_length=256, blank=True, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)
	revoluciones = models.CharField('Revoluciones', max_length=256, blank=True, null=True)
	modelo = models.CharField('Modelo', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
####################################
###### OK ######



###### OK ######
class balas(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	volumen = models.FloatField('Volumen (m3)', max_length=256, blank=True, null=True)
	tipo_balas = models.ForeignKey(tipo_balas, blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
###### OK ######






class suavizadores(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	capacidad_calderas = models.FloatField('Capacidad de Caldera (kg)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)




###################LISTO##################
class equipo_cocina(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	tipo_sist_eq_cocina = models.ForeignKey(tipo_sistema, blank=True, null=True)
	capacidad = models.FloatField('Capacidad (lts)', max_length=256, blank=True, null=True)
	cant_fuegos = models.SmallIntegerField('Cantidad de Fuegos', max_length=256, blank=True, null=True)
	cant_gavetas = models.SmallIntegerField('Cantidad de Gavetas', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
####################################




###################LISTO##################
class equipo_lavanderia(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	tipo_sist_eq_lavanderia = models.ForeignKey(tipo_sistema, blank=True, null=True)
	capacidad = models.FloatField('Capacidad (kg)', max_length=256, blank=True, null=True)
	long_cilidro = models.FloatField('Longitud Útil del Cilindro (mm)', max_length=256, blank=True, null=True)
	diametro_cilidro = models.FloatField('Diámetro del Cilindro (mm)', max_length=256, blank=True, null=True)
	productividad = models.FloatField('Productividad (kg/h)', max_length=256, blank=True, null=True)
	prensa = models.CharField('Tipo de prensa', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
####################################



###################LISTO##################
class grupo_electrogeno(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	marca = models.ForeignKey(marca_grupo_electrogeno, blank=True, max_length=256, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	serviciador = models.ForeignKey(serviciador_grupo_electrogeno, blank=True, max_length=256, null=True)
	tipo = models.ForeignKey(tipo_grupo_electrogeno, blank=True, max_length=256, null=True)
	potencia = models.FloatField('Potencia (kVA)', max_length=256, blank=True, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)
	cpropia = models.CharField('Capacidad Propia', max_length=256, blank=True, null=True)
	cauxili = models.CharField('Capacidad Auxiliar', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	observacion = models.CharField('Observacion', max_length=2048, blank=True, null=True)

	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
####################################



class sist_extraccion_inyeccion(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % (self.unidad)




###################LISTO##################
class campana_extraccion_gases(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	sist_extraccion_inyeccion = models.ForeignKey(sist_extraccion_inyeccion, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	long_frontal = models.FloatField('Longitud Frontal (mm)', max_length=256, blank=True, null=True)
	long_lateral = models.FloatField('Longitud Lateral (mm)', max_length=256, blank=True, null=True)
	altura = models.FloatField('Altura (mm)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s' % ( self.unidad)
####################################


###################LISTO##################

class ventilador(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	sist_extraccion_inyeccion = models.ForeignKey(sist_extraccion_inyeccion, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	tipo_ventilador = models.ForeignKey(tipo_ventilador, blank=True, null=True)
	caudal = models.FloatField('Caudal (m3/h)', max_length=256, blank=True, null=True)
	presion = models.FloatField('Presión (m3/h)', max_length=256, blank=True, null=True)
	potencia = models.FloatField('Potencia (kW)', max_length=256, blank=True, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)
	peso = models.FloatField('Peso (kg)', max_length=256, blank=True, null=True)
	velocidad = models.FloatField('Velocidad de Rotación (rpm)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s%s' % ('Ventilador', self.tipo_ventilador,'-', super.unidad)
####################################



class calentador_solar(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	volumen = models.FloatField('Volumen (lts)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)



###################LISTO##################
class panel_solar(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	potencia = models.FloatField('Potencia (kW)', max_length=256, blank=True, null=True)
	tension = models.FloatField('Tensión (V)', max_length=256, blank=True, null=True)
	fase = models.FloatField('Fase (Ph)', max_length=256, blank=True, null=True)
	frecuencia = models.FloatField('Frecuencia (Hz)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)
####################################



class incinerador(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni = models.CharField('Número de Inventario', max_length=256, blank=True, null=True)
	estado = models.ForeignKey(estado, blank=True, max_length=256, null=True)
	capacidad = models.FloatField('Capacidad (kg)', max_length=256, blank=True, null=True)

	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)






class tipo_camaras_frias(models.Model):
	tipo = models.CharField('Tipo de Camaras Frias', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.tipo)









class camaras_frias(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni= models.CharField('INVENTARIO', max_length=256, blank=False, null=False)
	tipo = models.ForeignKey(tipo_camaras_frias, blank=True, null=True)
	largo= models.CharField('LARGO', max_length=256, blank=False, null=False)
	ancho= models.CharField('ANCHO', max_length=256, blank=False, null=False)
	alto= models.CharField('ALTO', max_length=256, blank=False, null=False)
	volumen= models.CharField('VOLUMEN', max_length=256, blank=False, null=False)
	capacidad= models.CharField('CAPACIDAD', max_length=256, blank=False, null=False)
	modelo= models.CharField('MODELO', max_length=256, blank=False, null=False)
	mtto= models.CharField('MTTO', max_length=256, blank=False, null=False)
	activo= models.CharField('ACTIVO', max_length=256, blank=False, null=False)
	estado= models.CharField('ESTADO', max_length=256, blank=False, null=False)
	comentario= models.CharField('COMENTARIO', max_length=256, blank=False, null=False)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)








class serviciador_clima_consola(models.Model):
	serviciador = models.CharField('Serviciador', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.serviciador)


class marca_clima_consola(models.Model):
	marca = models.CharField('Marca', blank=True, max_length=256, null=True)
	activo = models.BooleanField('Activo', max_length = 256, blank=True)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)

	def __unicode__(self):
		return '%s' % (self.marca)


class clima_consola(models.Model):
	unidad = models.ForeignKey(Unidad, blank=True, null=True)
	ni= models.CharField('Inventario', max_length=256, blank=False, null=False)
	serviciador = models.ForeignKey(serviciador_clima, blank=True, null=True)
	marca = models.ForeignKey(marca_clima, blank=True, null=True)
	modelo= models.CharField('Modelo', max_length=256, blank=False, null=False)
	capacidad= models.CharField('capacidad', max_length=256, blank=False, null=False)
	activo= models.CharField('Activo', max_length=256, blank=False, null=False)
	estado= models.CharField('Estado', max_length=256, blank=False, null=False)
	comentario= models.CharField('Comentario', max_length=256, blank=False, null=False)
	registro = models.DateTimeField('Registrado', auto_now=True, auto_now_add=True)
	def __unicode__(self):
		return '%s%s%s' % (self.ni, '-', self.unidad)





