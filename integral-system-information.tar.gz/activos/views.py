from django.shortcuts import render


from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext

from activos.models import *

from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required


from activos.forms import  *
from django.db.models import Sum
from django.db.models import Count
#~ from qrcode import *



@login_required(login_url='/ingresar')
def listaactivos(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Contabilidad':

		id_unidad = request.session['unidad']
		unidad = Unidad.objects.get(id = id_unidad)

		fijos = activos.objects.all()


		for f in fijos:
			datos = str(f.inventario) + ', ' + str(f.dpto) + ', ' + str(f.nombre) + ', '  + str(f.descripcion)
			qr = QRCode(version=1, error_correction=ERROR_CORRECT_L)
			qr.add_data(datos)
			qr.make()
			im = qr.make_image()
			im.save ('/var/www/sii/imagen_qr_activo/' + str(f.inventario)+ '_' + str(f.nombre.id) + ".png")




		return render_to_response('activos/activos.html',{
		'fijos':fijos,
		'unidad':unidad,
		}, context_instance=RequestContext(request))
	else:
		return HttpResponseRedirect('/')









@login_required(login_url='/ingresar')
def form_activo(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Contabilidad':

		id_unidad = request.session['unidad']
		unidad = Unidad.objects.get(id = id_unidad)
		datos=""

		if request.method=='POST':
			form_activos = formulario_activos(request.POST, request.FILES)
			if form_activos.is_valid():
				form = form_activos.save(commit=False)

				datos = str(form.inventario) + ', ' + str(form.dpto) + ', ' + str(form.nombre) + ', '  + str(form.descripcion)



				form.imagen = str(form.inventario) + ".png"
				
				form.save()
				form_activos.save_m2m()

				qr = QRCode(version=1, error_correction=ERROR_CORRECT_L)
				qr.add_data(datos)
				qr.make()
				im = qr.make_image()
				im.save ('/var/www/sii/imagen_qr_activo/' + str(form.inventario) + ".png")



				return HttpResponseRedirect('/activos')


		else:
			form_activos = formulario_activos()
		return render_to_response('activos/formulario.activos.html',{'form_activos':form_activos, 'unidad':unidad} , context_instance=RequestContext(request))
	else:
		return HttpResponseRedirect('/')


@login_required(login_url='/ingresar')
def form_editar_activo(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Contabilidad':

		id_unidad = request.session['unidad']
		unidad=Unidad.objects.get(id=id_unidad)
		datos=""

		id_activo = request.GET.get('id_activo')
		activo = activos.objects.get(id=id_activo)


		if request.method=='POST':
			form_activos = formulario_activos(request.POST, instance=activo)
			if form_activos.is_valid():
				form = form_activos.save(commit=False)
				
				datos = str(form.inventario) + ', ' + str(form.dpto) + ', ' + str(form.nombre) + ', '  + str(form.descripcion)
				
				form.imagen = str(form.inventario) + ".png"
				form.save()
				form_activos.save_m2m()

				qr = QRCode(version=1, error_correction=ERROR_CORRECT_L)
				qr.add_data(datos)
				qr.make()
				im = qr.make_image()
				im.save ('/var/www/sii/imagen_qr_activo/' + str(form.inventario) + ".png")

				return HttpResponseRedirect('/activos')
		else:
			form_activos = formulario_activos(instance=activo)
		return render_to_response('activos/formulario.activos.html',{'form_activos':form_activos, 'unidad':unidad} , context_instance=RequestContext(request))
	else:
		return HttpResponseRedirect('/')



@login_required(login_url='/ingresar')
def eliminar_activo(request):
	organizativa = request.session['organizativa']
	if organizativa == 'Contabilidad':

		id_activo = request.GET.get('id_activo')
		activo = activos.objects.get(id=id_activo)
		activo.delete()
		return HttpResponseRedirect('/activos')


	else:
		return HttpResponseRedirect('/')


