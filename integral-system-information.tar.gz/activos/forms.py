from django.forms import *
from django import forms
from activos.models import *


class formulario_activos(ModelForm):
	class Meta:
		model = activos
		widgets = {
'subMayor': Select(attrs={"class" :"select2",'placeholder': 'Submayor','required':'true'}),
'cnmb': Select(attrs={"class" :"select2",'placeholder': 'CNMB','required':'true'}),
'inventario': TextInput(attrs={'class' :'form-control','placeholder': 'Inventario','required':'true'}),
'nombre': Select(attrs={'class' :'select2','placeholder': 'Activo','required':'true'}),
'dpto': Select(attrs={"class" :"select2",'placeholder': 'Departamento','required':'true'}),
'descripcion': TextInput(attrs={'class' :'form-control','placeholder': 'Descripcion'}),
'importe_activo': TextInput(attrs={'class' :'form-control','placeholder': 'Importe','required':'true'}),

}
