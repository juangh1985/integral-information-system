from django.forms import *
from django import forms
from mensajes.models import *


class Formulario_Mensaje(ModelForm):
	class Meta:
		model = mensaje
		exclude=('estado', 'registro', 'ip', 'remitente', 'respuesta', 'enviado', 'eliminado')
		widgets = {
			'asunto': TextInput(attrs={'class' :'form-control','placeholder': 'Asunto','required':'true'}),
			'texto': Textarea(attrs={"id":"textarea", "class":"form-control", "rows":"6", "cols":"30", "maxlength":"1024", 'placeholder': 'Texto','required':'true'}),
			'categoria': Select(attrs={'class' :'select2','placeholder': 'Opciones','required':'true'}),
			'destinatario': SelectMultiple(attrs={'multiple':'', 'class' :'select2 select2-multiple','placeholder': 'Destinatarios'}),
			}
