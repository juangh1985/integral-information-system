from django.shortcuts import render
from django.shortcuts import render_to_response, get_object_or_404
from django.template import RequestContext
from tareas.views import *
from models import *
from mensajes.forms import *
from django.core.mail import EmailMessage
from django.http import HttpResponseRedirect, HttpRequest
from django.core.paginator import Paginator, InvalidPage, EmptyPage
from django.db.models import Q

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required

from django.db.models import Sum
from django.db.models import Count


from django.views.generic import UpdateView




@login_required(login_url='/ingresar')	
def contacto(request):
	id_mensaje = request.GET.get('id_mensaje')
	id_respuesta = request.GET.get('id_respuesta')
	id_eliminado = request.GET.get('eliminado')
	id_restablecido = request.GET.get('restablecido')
	id_purgado = request.GET.get('purgado')
	id_quitar = request.GET.get('quitar')
	id_enviado = request.GET.get('enviado')
	papelera = request.GET.get('papelera')
	purgardo = request.GET.get('purgardo')
	perfil = Perfil.objects.get(user=request.session['userid'])
	lista_categoria = categoria.objects.all()
	if perfil.user.is_staff:
		mensa = mensaje.objects.filter(destinatario=perfil.trabajador.id, estado = 0)
		mens = []
		mensajes_todos = mensaje.objects.all().annotate(tiene = Count('eliminar_destinatario__mensaje'))
		for m in mensajes_todos:
			if m.destinatario.count() ==0 and m.tiene ==0:
				mens.append(m)
		for me in mensa:
			mens.append(me)
	else:
		mens = mensaje.objects.filter(destinatario=perfil.trabajador.id)
	vistos = mensaje_leido.objects.filter(trabajador = perfil.trabajador).count()
	noleidos = len(mens) - vistos
		
	
	inbox = mensaje.objects.filter(destinatario = perfil.trabajador.id).count
	mens1 = mensaje.objects.filter(remitente=request.session['userid'], estado = 0)
	elimina_enviado = mensaje.objects.filter(remitente=request.session['userid'], estado = 1)
	eliminados = []
	for elimina in elimina_enviado:
		eliminados.append(elimina)
	#aki esta el problemaaaaaaaaaaaaa!!!!!!!!!!
	elimina_entrada = eliminar_destinatario.objects.filter(trabajador=perfil.trabajador, eliminado =0)
	for eliminar in elimina_entrada:
		if str(eliminar.mensaje.estado) == str(1):
			eliminados.append(eliminar)
	leidoss = mensaje_leido.objects.filter(trabajador = perfil.trabajador)
	leidos = []
	for leido in leidoss:
		leidos.append(leido.mensaje.id)

	trabajadoress = Trabajador.objects.annotate(have=Count('perfil__trabajador'))
	unidades_sub= Unidad.objects.filter(subordinacion=request.session['unidad']).order_by('-municipio')
	destinatarios = []
	for trabajador in trabajadoress:
		for unidad_sub in unidades_sub:
			if trabajador.plaza_ocupa.departamento.unidad==unidad_sub and trabajador.have == 1:
					destinatarios.append(trabajador)
		if str(trabajador.plaza_ocupa.departamento.unidad.id)==str(request.session['unidad']) and str(trabajador.id) != str(request.session['trabajador'])and trabajador.have == 1:
				destinatarios.append(trabajador)
	
	
	if id_enviado:
		form_mensaje = Formulario_Mensaje()
		ver_enviado = mensaje.objects.get(id=id_enviado)
		mis_destinatarios = []
		lista_eliminados = eliminar_destinatario.objects.all()
		for lista in lista_eliminados:
			if lista.mensaje.id==ver_enviado.id:
				mis_destinatarios.append(lista.trabajador)
				
		print mis_destinatarios
		remitentee = Perfil.objects.get(user=ver_enviado.remitente.id)
		foto = Trabajador.objects.get(id = remitentee.trabajador.id)
		
		return render_to_response('mensajes/bandeja_entrada.html', 
		{'inbox':inbox,
		'mens1':mens1,
		'mens':mens,
		'leidos':leidos,
		'papelera':papelera,
		'purgardo':purgardo,
		#'ver':ver,
		'ver_enviado':ver_enviado,
		'foto':foto,
		'noleidos':noleidos,
		
		'remitentee':remitentee,
		'mis_destinatarios':mis_destinatarios,
		'id_mensaje':id_mensaje,
		'id_respuesta':id_respuesta,
		'id_enviado':id_enviado,
		'eliminados':eliminados,
		'destinatarios':destinatarios,
		'form_mensaje':form_mensaje, }, context_instance=RequestContext(request))
		
	if id_quitar:
		mensaje_mio = mensaje.objects.get(id = id_quitar)
		mensaje_mio.estado = 1
		mensaje_mio.save()
		borrar_visto = mensaje_leido.objects.filter(mensaje = mensaje_mio, trabajador = perfil.trabajador)
		if borrar_visto:
			borrar_visto[0].delete()
		#print mensaje_mio
		mensajes_eliminados = eliminar_destinatario(mensaje=mensaje_mio, trabajador = perfil.trabajador, eliminado = 0)
		mensajes_eliminados.save()
		mensaje_mio.destinatario.remove(perfil.trabajador)
		#mensaje_mio.destinatario.remove(perfil.trabajador)
		return HttpResponseRedirect('/contacto?quitar=')
	if id_eliminado:
		elimina = mensaje.objects.get(id = id_eliminado)
		if elimina.remitente.id == request.session['userid']:
			elimina.estado = 1
			elimina.save()
		else:
			cambia_estado = eliminar_destinatario.objects.filter(mensaje = elimina, trabajador = perfil.trabajador)
			cambia_estado.mensaje.estado = 1
			cambia_estado.save()
		
		return HttpResponseRedirect('/contacto?papelera=0')
	if id_restablecido:
		restablece = mensaje.objects.get(id = id_restablecido)
		if restablece.remitente.id == request.session['userid']:
			restablece.estado = 0
			restablece.save()
		else:
			restablecer = eliminar_destinatario.objects.filter(mensaje = restablece, trabajador = perfil.trabajador)
			restablece.destinatario.add(perfil.trabajador)
			print restablece.destinatario.all()
			print perfil.trabajador
			restablecer[0].delete()
			restablece.estado = 0
			restablece.save()
		return HttpResponseRedirect('/contacto?purgardo=0')
	if id_purgado:
		purgar_enviado = mensaje.objects.get(id = id_purgado)
		if purgar_enviado.remitente.id == request.session['userid']:
			print purgar_enviado.id
			print id_purgado
			purgar_enviado.estado = 2
			purgar_enviado.save()
		else:
			
			purgar_entrada = eliminar_destinatario.objects.get(mensaje = purgar_enviado, trabajador = perfil.trabajador)
			purgar_entrada.eliminado = 1
			purgar_entrada.save()
		return HttpResponseRedirect('/contacto?purgardo=0')
	if request.method=='POST':
		form_mensaje = Formulario_Mensaje(request.POST)
		if form_mensaje.is_valid():
			form = form_mensaje.save(commit=False)
			form.ip = request.META['REMOTE_ADDR']
			form.remitente = perfil.user
			form.activo = False
			# el 0 es entrada, el 1 es eliminado y el 2 es purgado
			form.estado = '0'
			form.save()
			form_mensaje.save_m2m()
			return HttpResponseRedirect('/contacto')
	else:
		form_mensaje = Formulario_Mensaje()
	if id_mensaje or id_respuesta:
		b_leido = 'no'
		if id_mensaje:
			ver = mensaje.objects.get(id=id_mensaje)
			mensajes_leidos = mensaje_leido(mensaje=ver, trabajador = perfil.trabajador)
			leidos = mensaje_leido.objects.all()
			vistos = mensaje_leido.objects.filter(trabajador = perfil.trabajador).count()
			noleidos = len(mens) - vistos
			for leid in leidos:
				if leid.mensaje == ver and leid.trabajador == perfil.trabajador:
					b_leido = 'si'
			if b_leido== 'no':
				mensajes_leidos.save()
				if request.user.is_staff:
						mensajes_sin_moderar = mensaje.objects.filter(Q(estado=0,destinatario=perfil.trabajador.id)|Q(estado=0,destinatario__isnull=True))
				else:
					mensajes_sin_moderar = mensaje.objects.filter(estado=0,destinatario=perfil.trabajador.id) 
				request.session['mensajes']={}

				for mensaje1 in mensajes_sin_moderar:
					if mensaje_leido.objects.filter(mensaje=mensaje1,trabajador=request.session['trabajador']).count()==0:
						request.session['mensajes'][str(mensaje1.id)]='<div class="pull-left"><img class="media-object" src="Galeria/'+str(Perfil.objects.get(user_id=mensaje1.remitente).trabajador.imagen)+'" ></div><div class="media-body"><h5 class="media-heading name">'+mensaje1.remitente.username+'</h5><p class="text">' + mensaje1.asunto + '</p><span class="timestamp">'+mensaje1.registro.strftime('%d-%m-%Y')+'</span></div>'
				
			leidos = mensaje_leido.objects.all()
		else:
			ver = mensaje.objects.get(id=id_respuesta)
		remitentee = Perfil.objects.get(user=ver.remitente.id)
		foto = Trabajador.objects.get(id = remitentee.trabajador.id)	
		return render_to_response('mensajes/bandeja_entrada.html', 
		{'inbox':inbox,
		'mens1':mens1,
		'mens':mens,
		'leidos':leidos,
		'papelera':papelera,
		'purgardo':purgardo,
		'ver':ver,
		'perfil':perfil,
		'noleidos':noleidos,
		
		'foto':foto,
		'remitentee':remitentee,
		'id_mensaje':id_mensaje,
		'id_respuesta':id_respuesta,
		'eliminados':eliminados,
		'destinatarios':destinatarios,
		'form_mensaje':form_mensaje, }, context_instance=RequestContext(request))
	else:
	#suma = Mensajes.objects.filter(leido=0, para = request.session['userid']).count
		return render_to_response('mensajes/bandeja_entrada.html', 
		{'inbox':inbox,
		'mens1':mens1,
		'mens':mens,
		'papelera':papelera,
		'purgardo':purgardo,
		'noleidos':noleidos,
		
		'perfil':perfil,
		'leidos':leidos,
		'eliminados':eliminados,
		'destinatarios':destinatarios,
		'form_mensaje':form_mensaje, }, context_instance=RequestContext(request))
